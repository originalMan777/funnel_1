<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Communications\TestSendCommunicationTemplateRequest;
use App\Models\CommunicationTemplate;
use App\Services\Communications\CommunicationTemplateTestSendService;
use Illuminate\Http\RedirectResponse;

class CommunicationTemplateTestSendController extends Controller
{
    public function __construct(
        private readonly CommunicationTemplateTestSendService $testSendService,
    ) {}

    public function store(TestSendCommunicationTemplateRequest $request, CommunicationTemplate $template): RedirectResponse
    {
        $recipient = $request->validatedRecipient();

        $this->testSendService->sendTest(
            $template,
            $request->validatedDraftContent(),
            $request->validatedSamplePayload(),
            $recipient['to_email'],
            $recipient['to_name'] ?? null,
        );

        return back()->with('success', 'Communication template test email sent.');
    }
}

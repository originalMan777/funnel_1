<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Communications\PublishCommunicationTemplateVersionRequest;
use App\Http\Requests\Admin\Communications\StoreCommunicationTemplateVersionRequest;
use App\Models\CommunicationTemplate;
use App\Models\CommunicationTemplateVersion;
use App\Services\Communications\CommunicationTemplatePublishingService;
use App\Services\Communications\CommunicationTemplateVersionService;
use Illuminate\Http\RedirectResponse;

class CommunicationTemplateVersionController extends Controller
{
    public function __construct(
        private readonly CommunicationTemplateVersionService $versionService,
        private readonly CommunicationTemplatePublishingService $publishingService,
    ) {}

    public function store(StoreCommunicationTemplateVersionRequest $request, CommunicationTemplate $template): RedirectResponse
    {
        $this->versionService->createVersion(
            $template,
            $request->validatedVersionData(),
            auth()->id(),
        );

        return back()->with('success', 'Communication template version created.');
    }

    public function publish(PublishCommunicationTemplateVersionRequest $request, CommunicationTemplate $template, CommunicationTemplateVersion $version): RedirectResponse
    {
        abort_unless((int) $version->communication_template_id === (int) $template->id, 404);

        $this->publishingService->publish($template, $version);

        return back()->with('success', 'Communication template version published.');
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Communications\StoreCommunicationTemplateRequest;
use App\Http\Requests\Admin\Communications\UpdateCommunicationTemplateRequest;
use App\Models\CommunicationTemplate;
use App\Services\Communications\CommunicationTemplateService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;

class CommunicationTemplateController extends Controller
{
    public function __construct(
        private readonly CommunicationTemplateService $templateService,
    ) {}

    public function index(): JsonResponse
    {
        return response()->json([
            'templates' => CommunicationTemplate::query()
                ->with(['currentVersion', 'bindings'])
                ->latest('id')
                ->get(),
        ]);
    }

    public function create(): JsonResponse
    {
        return response()->json([
            'message' => 'Communication template create placeholder.',
        ]);
    }

    public function store(StoreCommunicationTemplateRequest $request): RedirectResponse
    {
        $this->templateService->create(
            $request->validatedTemplateData(),
            $request->validatedBindings(),
            auth()->id(),
        );

        return back()->with('success', 'Communication template created.');
    }

    public function show(CommunicationTemplate $template): JsonResponse
    {
        $template->load(['currentVersion', 'versions', 'bindings']);

        return response()->json([
            'template' => $template,
        ]);
    }

    public function edit(CommunicationTemplate $template): JsonResponse
    {
        $template->load(['currentVersion', 'versions', 'bindings']);

        return response()->json([
            'template' => $template,
            'message' => 'Communication template edit placeholder.',
        ]);
    }

    public function update(UpdateCommunicationTemplateRequest $request, CommunicationTemplate $template): RedirectResponse
    {
        $this->templateService->update(
            $template,
            $request->validatedTemplateData(),
            $request->validatedBindings(),
            auth()->id(),
        );

        return back()->with('success', 'Communication template updated.');
    }
}

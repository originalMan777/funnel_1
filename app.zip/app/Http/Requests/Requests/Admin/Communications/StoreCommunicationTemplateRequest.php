<?php

namespace App\Http\Requests\Admin\Communications;

use App\Models\CommunicationTemplate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreCommunicationTemplateRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'key' => [
                'required',
                'string',
                'max:255',
                'alpha_dash',
                Rule::unique('communication_templates', 'key'),
            ],
            'name' => [
                'required',
                'string',
                'max:255',
            ],
            'status' => [
                'required',
                'string',
                Rule::in([
                    CommunicationTemplate::STATUS_DRAFT,
                    CommunicationTemplate::STATUS_ACTIVE,
                    CommunicationTemplate::STATUS_ARCHIVED,
                ]),
            ],
            'description' => [
                'nullable',
                'string',
            ],
            'from_name_override' => [
                'nullable',
                'string',
                'max:255',
            ],
            'from_email_override' => [
                'nullable',
                'email',
                'max:255',
            ],
            'reply_to_email' => [
                'nullable',
                'email',
                'max:255',
            ],

            'bindings' => [
                'nullable',
                'array',
            ],
            'bindings.*.event_key' => [
                'required_with:bindings',
                'string',
                'max:255',
            ],
            'bindings.*.action_key' => [
                'required_with:bindings',
                'string',
                'max:255',
            ],
            'bindings.*.is_enabled' => [
                'nullable',
                'boolean',
            ],
            'bindings.*.priority' => [
                'nullable',
                'integer',
                'min:1',
            ],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function attributes(): array
    {
        return [
            'key' => 'template key',
            'name' => 'template name',
            'status' => 'template status',
            'from_name_override' => 'from name override',
            'from_email_override' => 'from email override',
            'reply_to_email' => 'reply-to email',
            'bindings.*.event_key' => 'binding event key',
            'bindings.*.action_key' => 'binding action key',
            'bindings.*.is_enabled' => 'binding enabled state',
            'bindings.*.priority' => 'binding priority',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    public function validatedTemplateData(): array
    {
        $data = $this->safe()->only([
            'key',
            'name',
            'status',
            'description',
            'from_name_override',
            'from_email_override',
            'reply_to_email',
        ]);

        $data['channel'] = CommunicationTemplate::CHANNEL_EMAIL;
        $data['category'] = CommunicationTemplate::CATEGORY_TRANSACTIONAL;

        return $data;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function validatedBindings(): array
    {
        return collect($this->validated('bindings', []))
            ->map(fn (array $binding): array => [
                'event_key' => $binding['event_key'],
                'action_key' => $binding['action_key'],
                'channel' => CommunicationTemplate::CHANNEL_EMAIL,
                'is_enabled' => (bool) ($binding['is_enabled'] ?? true),
                'priority' => (int) ($binding['priority'] ?? 100),
            ])
            ->values()
            ->all();
    }
}

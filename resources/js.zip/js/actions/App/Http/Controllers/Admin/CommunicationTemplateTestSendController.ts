import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateTestSendController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateTestSendController.php:19
* @route '/admin/communications/templates/{template}/test-send'
*/
export const store = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/communications/templates/{template}/test-send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateTestSendController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateTestSendController.php:19
* @route '/admin/communications/templates/{template}/test-send'
*/
store.url = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { template: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            template: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return store.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateTestSendController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateTestSendController.php:19
* @route '/admin/communications/templates/{template}/test-send'
*/
store.post = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateTestSendController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateTestSendController.php:19
* @route '/admin/communications/templates/{template}/test-send'
*/
const storeForm = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateTestSendController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateTestSendController.php:19
* @route '/admin/communications/templates/{template}/test-send'
*/
storeForm.post = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

const CommunicationTemplateTestSendController = { store }

export default CommunicationTemplateTestSendController
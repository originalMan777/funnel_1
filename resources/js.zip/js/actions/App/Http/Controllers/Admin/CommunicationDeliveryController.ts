import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::index
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:15
* @route '/admin/communications/deliveries'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/communications/deliveries',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::index
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:15
* @route '/admin/communications/deliveries'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::index
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:15
* @route '/admin/communications/deliveries'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::index
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:15
* @route '/admin/communications/deliveries'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::index
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:15
* @route '/admin/communications/deliveries'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::index
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:15
* @route '/admin/communications/deliveries'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::index
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:15
* @route '/admin/communications/deliveries'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::show
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:67
* @route '/admin/communications/deliveries/{communicationDelivery}'
*/
export const show = (args: { communicationDelivery: string | number | { id: string | number } } | [communicationDelivery: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/communications/deliveries/{communicationDelivery}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::show
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:67
* @route '/admin/communications/deliveries/{communicationDelivery}'
*/
show.url = (args: { communicationDelivery: string | number | { id: string | number } } | [communicationDelivery: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { communicationDelivery: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { communicationDelivery: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            communicationDelivery: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        communicationDelivery: typeof args.communicationDelivery === 'object'
        ? args.communicationDelivery.id
        : args.communicationDelivery,
    }

    return show.definition.url
            .replace('{communicationDelivery}', parsedArgs.communicationDelivery.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::show
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:67
* @route '/admin/communications/deliveries/{communicationDelivery}'
*/
show.get = (args: { communicationDelivery: string | number | { id: string | number } } | [communicationDelivery: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::show
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:67
* @route '/admin/communications/deliveries/{communicationDelivery}'
*/
show.head = (args: { communicationDelivery: string | number | { id: string | number } } | [communicationDelivery: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::show
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:67
* @route '/admin/communications/deliveries/{communicationDelivery}'
*/
const showForm = (args: { communicationDelivery: string | number | { id: string | number } } | [communicationDelivery: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::show
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:67
* @route '/admin/communications/deliveries/{communicationDelivery}'
*/
showForm.get = (args: { communicationDelivery: string | number | { id: string | number } } | [communicationDelivery: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationDeliveryController::show
* @see app/Http/Controllers/Admin/CommunicationDeliveryController.php:67
* @route '/admin/communications/deliveries/{communicationDelivery}'
*/
showForm.head = (args: { communicationDelivery: string | number | { id: string | number } } | [communicationDelivery: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const CommunicationDeliveryController = { index, show }

export default CommunicationDeliveryController
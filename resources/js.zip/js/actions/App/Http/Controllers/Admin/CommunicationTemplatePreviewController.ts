import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CommunicationTemplatePreviewController::store
* @see app/Http/Controllers/Admin/CommunicationTemplatePreviewController.php:19
* @route '/admin/communications/templates/{template}/preview'
*/
export const store = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/communications/templates/{template}/preview',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplatePreviewController::store
* @see app/Http/Controllers/Admin/CommunicationTemplatePreviewController.php:19
* @route '/admin/communications/templates/{template}/preview'
*/
store.url = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { template: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            template: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return store.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplatePreviewController::store
* @see app/Http/Controllers/Admin/CommunicationTemplatePreviewController.php:19
* @route '/admin/communications/templates/{template}/preview'
*/
store.post = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplatePreviewController::store
* @see app/Http/Controllers/Admin/CommunicationTemplatePreviewController.php:19
* @route '/admin/communications/templates/{template}/preview'
*/
const storeForm = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplatePreviewController::store
* @see app/Http/Controllers/Admin/CommunicationTemplatePreviewController.php:19
* @route '/admin/communications/templates/{template}/preview'
*/
storeForm.post = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

const CommunicationTemplatePreviewController = { store }

export default CommunicationTemplatePreviewController
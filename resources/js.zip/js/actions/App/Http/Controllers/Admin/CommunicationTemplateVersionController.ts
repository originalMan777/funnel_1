import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateVersionController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateVersionController.php:23
* @route '/admin/communications/templates/{template}/versions'
*/
export const store = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/communications/templates/{template}/versions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateVersionController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateVersionController.php:23
* @route '/admin/communications/templates/{template}/versions'
*/
store.url = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { template: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            template: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return store.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateVersionController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateVersionController.php:23
* @route '/admin/communications/templates/{template}/versions'
*/
store.post = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateVersionController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateVersionController.php:23
* @route '/admin/communications/templates/{template}/versions'
*/
const storeForm = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateVersionController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateVersionController.php:23
* @route '/admin/communications/templates/{template}/versions'
*/
storeForm.post = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateVersionController::publish
* @see app/Http/Controllers/Admin/CommunicationTemplateVersionController.php:50
* @route '/admin/communications/templates/{template}/versions/{version}/publish'
*/
export const publish = (args: { template: string | number | { id: string | number }, version: string | number | { id: string | number } } | [template: string | number | { id: string | number }, version: string | number | { id: string | number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

publish.definition = {
    methods: ["post"],
    url: '/admin/communications/templates/{template}/versions/{version}/publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateVersionController::publish
* @see app/Http/Controllers/Admin/CommunicationTemplateVersionController.php:50
* @route '/admin/communications/templates/{template}/versions/{version}/publish'
*/
publish.url = (args: { template: string | number | { id: string | number }, version: string | number | { id: string | number } } | [template: string | number | { id: string | number }, version: string | number | { id: string | number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            template: args[0],
            version: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
        version: typeof args.version === 'object'
        ? args.version.id
        : args.version,
    }

    return publish.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace('{version}', parsedArgs.version.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateVersionController::publish
* @see app/Http/Controllers/Admin/CommunicationTemplateVersionController.php:50
* @route '/admin/communications/templates/{template}/versions/{version}/publish'
*/
publish.post = (args: { template: string | number | { id: string | number }, version: string | number | { id: string | number } } | [template: string | number | { id: string | number }, version: string | number | { id: string | number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateVersionController::publish
* @see app/Http/Controllers/Admin/CommunicationTemplateVersionController.php:50
* @route '/admin/communications/templates/{template}/versions/{version}/publish'
*/
const publishForm = (args: { template: string | number | { id: string | number }, version: string | number | { id: string | number } } | [template: string | number | { id: string | number }, version: string | number | { id: string | number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: publish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateVersionController::publish
* @see app/Http/Controllers/Admin/CommunicationTemplateVersionController.php:50
* @route '/admin/communications/templates/{template}/versions/{version}/publish'
*/
publishForm.post = (args: { template: string | number | { id: string | number }, version: string | number | { id: string | number } } | [template: string | number | { id: string | number }, version: string | number | { id: string | number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: publish.url(args, options),
    method: 'post',
})

publish.form = publishForm

const CommunicationTemplateVersionController = { store, publish }

export default CommunicationTemplateVersionController
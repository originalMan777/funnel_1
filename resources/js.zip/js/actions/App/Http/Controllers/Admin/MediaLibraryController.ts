import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::index
* @see app/Http/Controllers/Admin/MediaLibraryController.php:43
* @route '/admin/media'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/media',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::index
* @see app/Http/Controllers/Admin/MediaLibraryController.php:43
* @route '/admin/media'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::index
* @see app/Http/Controllers/Admin/MediaLibraryController.php:43
* @route '/admin/media'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::index
* @see app/Http/Controllers/Admin/MediaLibraryController.php:43
* @route '/admin/media'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::index
* @see app/Http/Controllers/Admin/MediaLibraryController.php:43
* @route '/admin/media'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::index
* @see app/Http/Controllers/Admin/MediaLibraryController.php:43
* @route '/admin/media'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::index
* @see app/Http/Controllers/Admin/MediaLibraryController.php:43
* @route '/admin/media'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::browser
* @see app/Http/Controllers/Admin/MediaLibraryController.php:52
* @route '/admin/media/browser'
*/
export const browser = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: browser.url(options),
    method: 'get',
})

browser.definition = {
    methods: ["get","head"],
    url: '/admin/media/browser',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::browser
* @see app/Http/Controllers/Admin/MediaLibraryController.php:52
* @route '/admin/media/browser'
*/
browser.url = (options?: RouteQueryOptions) => {
    return browser.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::browser
* @see app/Http/Controllers/Admin/MediaLibraryController.php:52
* @route '/admin/media/browser'
*/
browser.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: browser.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::browser
* @see app/Http/Controllers/Admin/MediaLibraryController.php:52
* @route '/admin/media/browser'
*/
browser.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: browser.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::browser
* @see app/Http/Controllers/Admin/MediaLibraryController.php:52
* @route '/admin/media/browser'
*/
const browserForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: browser.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::browser
* @see app/Http/Controllers/Admin/MediaLibraryController.php:52
* @route '/admin/media/browser'
*/
browserForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: browser.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::browser
* @see app/Http/Controllers/Admin/MediaLibraryController.php:52
* @route '/admin/media/browser'
*/
browserForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: browser.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

browser.form = browserForm

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::feed
* @see app/Http/Controllers/Admin/MediaLibraryController.php:61
* @route '/admin/media/feed'
*/
export const feed = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: feed.url(options),
    method: 'get',
})

feed.definition = {
    methods: ["get","head"],
    url: '/admin/media/feed',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::feed
* @see app/Http/Controllers/Admin/MediaLibraryController.php:61
* @route '/admin/media/feed'
*/
feed.url = (options?: RouteQueryOptions) => {
    return feed.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::feed
* @see app/Http/Controllers/Admin/MediaLibraryController.php:61
* @route '/admin/media/feed'
*/
feed.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: feed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::feed
* @see app/Http/Controllers/Admin/MediaLibraryController.php:61
* @route '/admin/media/feed'
*/
feed.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: feed.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::feed
* @see app/Http/Controllers/Admin/MediaLibraryController.php:61
* @route '/admin/media/feed'
*/
const feedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: feed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::feed
* @see app/Http/Controllers/Admin/MediaLibraryController.php:61
* @route '/admin/media/feed'
*/
feedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: feed.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::feed
* @see app/Http/Controllers/Admin/MediaLibraryController.php:61
* @route '/admin/media/feed'
*/
feedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: feed.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

feed.form = feedForm

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::store
* @see app/Http/Controllers/Admin/MediaLibraryController.php:70
* @route '/admin/media'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/media',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::store
* @see app/Http/Controllers/Admin/MediaLibraryController.php:70
* @route '/admin/media'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::store
* @see app/Http/Controllers/Admin/MediaLibraryController.php:70
* @route '/admin/media'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::store
* @see app/Http/Controllers/Admin/MediaLibraryController.php:70
* @route '/admin/media'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::store
* @see app/Http/Controllers/Admin/MediaLibraryController.php:70
* @route '/admin/media'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::destroy
* @see app/Http/Controllers/Admin/MediaLibraryController.php:161
* @route '/admin/media'
*/
export const destroy = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/media',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::destroy
* @see app/Http/Controllers/Admin/MediaLibraryController.php:161
* @route '/admin/media'
*/
destroy.url = (options?: RouteQueryOptions) => {
    return destroy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::destroy
* @see app/Http/Controllers/Admin/MediaLibraryController.php:161
* @route '/admin/media'
*/
destroy.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::destroy
* @see app/Http/Controllers/Admin/MediaLibraryController.php:161
* @route '/admin/media'
*/
const destroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\MediaLibraryController::destroy
* @see app/Http/Controllers/Admin/MediaLibraryController.php:161
* @route '/admin/media'
*/
destroyForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const MediaLibraryController = { index, browser, feed, store, destroy }

export default MediaLibraryController
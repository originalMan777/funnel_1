import PostController from './PostController'
import AcquisitionContactController from './AcquisitionContactController'
import CommunicationOverviewController from './CommunicationOverviewController'
import Analytics from './Analytics'
import CommunicationEventController from './CommunicationEventController'
import CommunicationDeliveryController from './CommunicationDeliveryController'
import MarketingSyncController from './MarketingSyncController'
import CommunicationSettingsController from './CommunicationSettingsController'
import CommunicationComposerController from './CommunicationComposerController'
import CommunicationTemplateController from './CommunicationTemplateController'
import CommunicationTemplateVersionController from './CommunicationTemplateVersionController'
import CommunicationTemplatePreviewController from './CommunicationTemplatePreviewController'
import CommunicationTemplateTestSendController from './CommunicationTemplateTestSendController'
import CampaignController from './CampaignController'
import CampaignEnrollmentController from './CampaignEnrollmentController'
import BlogIndexSectionController from './BlogIndexSectionController'
import CategoryController from './CategoryController'
import TagController from './TagController'
import MediaLibraryController from './MediaLibraryController'
import LeadBoxController from './LeadBoxController'
import ResourceLeadBoxController from './ResourceLeadBoxController'
import ServiceLeadBoxController from './ServiceLeadBoxController'
import OfferLeadBoxController from './OfferLeadBoxController'
import LeadSlotController from './LeadSlotController'
import PopupController from './PopupController'
import AiPostImporterController from './AiPostImporterController'
import QO from './QO'

const Admin = {
    PostController: Object.assign(PostController, PostController),
    AcquisitionContactController: Object.assign(AcquisitionContactController, AcquisitionContactController),
    CommunicationOverviewController: Object.assign(CommunicationOverviewController, CommunicationOverviewController),
    Analytics: Object.assign(Analytics, Analytics),
    CommunicationEventController: Object.assign(CommunicationEventController, CommunicationEventController),
    CommunicationDeliveryController: Object.assign(CommunicationDeliveryController, CommunicationDeliveryController),
    MarketingSyncController: Object.assign(MarketingSyncController, MarketingSyncController),
    CommunicationSettingsController: Object.assign(CommunicationSettingsController, CommunicationSettingsController),
    CommunicationComposerController: Object.assign(CommunicationComposerController, CommunicationComposerController),
    CommunicationTemplateController: Object.assign(CommunicationTemplateController, CommunicationTemplateController),
    CommunicationTemplateVersionController: Object.assign(CommunicationTemplateVersionController, CommunicationTemplateVersionController),
    CommunicationTemplatePreviewController: Object.assign(CommunicationTemplatePreviewController, CommunicationTemplatePreviewController),
    CommunicationTemplateTestSendController: Object.assign(CommunicationTemplateTestSendController, CommunicationTemplateTestSendController),
    CampaignController: Object.assign(CampaignController, CampaignController),
    CampaignEnrollmentController: Object.assign(CampaignEnrollmentController, CampaignEnrollmentController),
    BlogIndexSectionController: Object.assign(BlogIndexSectionController, BlogIndexSectionController),
    CategoryController: Object.assign(CategoryController, CategoryController),
    TagController: Object.assign(TagController, TagController),
    MediaLibraryController: Object.assign(MediaLibraryController, MediaLibraryController),
    LeadBoxController: Object.assign(LeadBoxController, LeadBoxController),
    ResourceLeadBoxController: Object.assign(ResourceLeadBoxController, ResourceLeadBoxController),
    ServiceLeadBoxController: Object.assign(ServiceLeadBoxController, ServiceLeadBoxController),
    OfferLeadBoxController: Object.assign(OfferLeadBoxController, OfferLeadBoxController),
    LeadSlotController: Object.assign(LeadSlotController, LeadSlotController),
    PopupController: Object.assign(PopupController, PopupController),
    AiPostImporterController: Object.assign(AiPostImporterController, AiPostImporterController),
    QO: Object.assign(QO, QO),
}

export default Admin
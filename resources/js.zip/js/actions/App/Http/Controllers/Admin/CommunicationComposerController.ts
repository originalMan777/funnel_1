import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::index
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:22
* @route '/admin/communications/composer'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/communications/composer',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::index
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:22
* @route '/admin/communications/composer'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::index
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:22
* @route '/admin/communications/composer'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::index
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:22
* @route '/admin/communications/composer'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::index
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:22
* @route '/admin/communications/composer'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::index
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:22
* @route '/admin/communications/composer'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::index
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:22
* @route '/admin/communications/composer'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::preview
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:32
* @route '/admin/communications/composer/preview'
*/
export const preview = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: preview.url(options),
    method: 'post',
})

preview.definition = {
    methods: ["post"],
    url: '/admin/communications/composer/preview',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::preview
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:32
* @route '/admin/communications/composer/preview'
*/
preview.url = (options?: RouteQueryOptions) => {
    return preview.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::preview
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:32
* @route '/admin/communications/composer/preview'
*/
preview.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: preview.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::preview
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:32
* @route '/admin/communications/composer/preview'
*/
const previewForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: preview.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::preview
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:32
* @route '/admin/communications/composer/preview'
*/
previewForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: preview.url(options),
    method: 'post',
})

preview.form = previewForm

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::send
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:42
* @route '/admin/communications/composer/send'
*/
export const send = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/admin/communications/composer/send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::send
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:42
* @route '/admin/communications/composer/send'
*/
send.url = (options?: RouteQueryOptions) => {
    return send.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::send
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:42
* @route '/admin/communications/composer/send'
*/
send.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::send
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:42
* @route '/admin/communications/composer/send'
*/
const sendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: send.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationComposerController::send
* @see app/Http/Controllers/Admin/CommunicationComposerController.php:42
* @route '/admin/communications/composer/send'
*/
sendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: send.url(options),
    method: 'post',
})

send.form = sendForm

const CommunicationComposerController = { index, preview, send }

export default CommunicationComposerController
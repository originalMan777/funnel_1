import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\LeadSlotController::index
* @see app/Http/Controllers/Admin/LeadSlotController.php:28
* @route '/admin/lead-slots'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/lead-slots',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::index
* @see app/Http/Controllers/Admin/LeadSlotController.php:28
* @route '/admin/lead-slots'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::index
* @see app/Http/Controllers/Admin/LeadSlotController.php:28
* @route '/admin/lead-slots'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::index
* @see app/Http/Controllers/Admin/LeadSlotController.php:28
* @route '/admin/lead-slots'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::index
* @see app/Http/Controllers/Admin/LeadSlotController.php:28
* @route '/admin/lead-slots'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::index
* @see app/Http/Controllers/Admin/LeadSlotController.php:28
* @route '/admin/lead-slots'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::index
* @see app/Http/Controllers/Admin/LeadSlotController.php:28
* @route '/admin/lead-slots'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::update
* @see app/Http/Controllers/Admin/LeadSlotController.php:112
* @route '/admin/lead-slots/{leadSlot}'
*/
export const update = (args: { leadSlot: string | number | { id: string | number } } | [leadSlot: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/lead-slots/{leadSlot}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::update
* @see app/Http/Controllers/Admin/LeadSlotController.php:112
* @route '/admin/lead-slots/{leadSlot}'
*/
update.url = (args: { leadSlot: string | number | { id: string | number } } | [leadSlot: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leadSlot: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { leadSlot: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            leadSlot: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        leadSlot: typeof args.leadSlot === 'object'
        ? args.leadSlot.id
        : args.leadSlot,
    }

    return update.definition.url
            .replace('{leadSlot}', parsedArgs.leadSlot.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::update
* @see app/Http/Controllers/Admin/LeadSlotController.php:112
* @route '/admin/lead-slots/{leadSlot}'
*/
update.put = (args: { leadSlot: string | number | { id: string | number } } | [leadSlot: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::update
* @see app/Http/Controllers/Admin/LeadSlotController.php:112
* @route '/admin/lead-slots/{leadSlot}'
*/
const updateForm = (args: { leadSlot: string | number | { id: string | number } } | [leadSlot: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\LeadSlotController::update
* @see app/Http/Controllers/Admin/LeadSlotController.php:112
* @route '/admin/lead-slots/{leadSlot}'
*/
updateForm.put = (args: { leadSlot: string | number | { id: string | number } } | [leadSlot: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const LeadSlotController = { index, update }

export default LeadSlotController
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::index
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:44
* @route '/admin/acquisition/contacts'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/acquisition/contacts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::index
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:44
* @route '/admin/acquisition/contacts'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::index
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:44
* @route '/admin/acquisition/contacts'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::index
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:44
* @route '/admin/acquisition/contacts'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::index
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:44
* @route '/admin/acquisition/contacts'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::index
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:44
* @route '/admin/acquisition/contacts'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::index
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:44
* @route '/admin/acquisition/contacts'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::storeTouch
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:119
* @route '/admin/acquisition/contacts/{contact}/touches'
*/
export const storeTouch = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTouch.url(args, options),
    method: 'post',
})

storeTouch.definition = {
    methods: ["post"],
    url: '/admin/acquisition/contacts/{contact}/touches',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::storeTouch
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:119
* @route '/admin/acquisition/contacts/{contact}/touches'
*/
storeTouch.url = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { contact: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { contact: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            contact: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        contact: typeof args.contact === 'object'
        ? args.contact.id
        : args.contact,
    }

    return storeTouch.definition.url
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::storeTouch
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:119
* @route '/admin/acquisition/contacts/{contact}/touches'
*/
storeTouch.post = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeTouch.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::storeTouch
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:119
* @route '/admin/acquisition/contacts/{contact}/touches'
*/
const storeTouchForm = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeTouch.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::storeTouch
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:119
* @route '/admin/acquisition/contacts/{contact}/touches'
*/
storeTouchForm.post = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeTouch.url(args, options),
    method: 'post',
})

storeTouch.form = storeTouchForm

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::updateState
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:78
* @route '/admin/acquisition/contacts/{contact}/state'
*/
export const updateState = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateState.url(args, options),
    method: 'patch',
})

updateState.definition = {
    methods: ["patch"],
    url: '/admin/acquisition/contacts/{contact}/state',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::updateState
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:78
* @route '/admin/acquisition/contacts/{contact}/state'
*/
updateState.url = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { contact: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { contact: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            contact: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        contact: typeof args.contact === 'object'
        ? args.contact.id
        : args.contact,
    }

    return updateState.definition.url
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::updateState
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:78
* @route '/admin/acquisition/contacts/{contact}/state'
*/
updateState.patch = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateState.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::updateState
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:78
* @route '/admin/acquisition/contacts/{contact}/state'
*/
const updateStateForm = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateState.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::updateState
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:78
* @route '/admin/acquisition/contacts/{contact}/state'
*/
updateStateForm.patch = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateState.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateState.form = updateStateForm

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::show
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:183
* @route '/admin/acquisition/contacts/{contact}'
*/
export const show = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/acquisition/contacts/{contact}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::show
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:183
* @route '/admin/acquisition/contacts/{contact}'
*/
show.url = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { contact: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { contact: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            contact: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        contact: typeof args.contact === 'object'
        ? args.contact.id
        : args.contact,
    }

    return show.definition.url
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::show
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:183
* @route '/admin/acquisition/contacts/{contact}'
*/
show.get = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::show
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:183
* @route '/admin/acquisition/contacts/{contact}'
*/
show.head = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::show
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:183
* @route '/admin/acquisition/contacts/{contact}'
*/
const showForm = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::show
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:183
* @route '/admin/acquisition/contacts/{contact}'
*/
showForm.get = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AcquisitionContactController::show
* @see app/Http/Controllers/Admin/AcquisitionContactController.php:183
* @route '/admin/acquisition/contacts/{contact}'
*/
showForm.head = (args: { contact: string | number | { id: string | number } } | [contact: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const AcquisitionContactController = { index, storeTouch, updateState, show }

export default AcquisitionContactController
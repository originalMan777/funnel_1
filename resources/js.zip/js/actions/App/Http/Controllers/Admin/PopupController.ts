import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\PopupController::index
* @see app/Http/Controllers/Admin/PopupController.php:22
* @route '/admin/popups'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/popups',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PopupController::index
* @see app/Http/Controllers/Admin/PopupController.php:22
* @route '/admin/popups'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PopupController::index
* @see app/Http/Controllers/Admin/PopupController.php:22
* @route '/admin/popups'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::index
* @see app/Http/Controllers/Admin/PopupController.php:22
* @route '/admin/popups'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::index
* @see app/Http/Controllers/Admin/PopupController.php:22
* @route '/admin/popups'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::index
* @see app/Http/Controllers/Admin/PopupController.php:22
* @route '/admin/popups'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::index
* @see app/Http/Controllers/Admin/PopupController.php:22
* @route '/admin/popups'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\PopupController::create
* @see app/Http/Controllers/Admin/PopupController.php:54
* @route '/admin/popups/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/popups/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PopupController::create
* @see app/Http/Controllers/Admin/PopupController.php:54
* @route '/admin/popups/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PopupController::create
* @see app/Http/Controllers/Admin/PopupController.php:54
* @route '/admin/popups/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::create
* @see app/Http/Controllers/Admin/PopupController.php:54
* @route '/admin/popups/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::create
* @see app/Http/Controllers/Admin/PopupController.php:54
* @route '/admin/popups/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::create
* @see app/Http/Controllers/Admin/PopupController.php:54
* @route '/admin/popups/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::create
* @see app/Http/Controllers/Admin/PopupController.php:54
* @route '/admin/popups/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\PopupController::store
* @see app/Http/Controllers/Admin/PopupController.php:61
* @route '/admin/popups'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/popups',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\PopupController::store
* @see app/Http/Controllers/Admin/PopupController.php:61
* @route '/admin/popups'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PopupController::store
* @see app/Http/Controllers/Admin/PopupController.php:61
* @route '/admin/popups'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::store
* @see app/Http/Controllers/Admin/PopupController.php:61
* @route '/admin/popups'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::store
* @see app/Http/Controllers/Admin/PopupController.php:61
* @route '/admin/popups'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\PopupController::edit
* @see app/Http/Controllers/Admin/PopupController.php:74
* @route '/admin/popups/{popup}/edit'
*/
export const edit = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/popups/{popup}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\PopupController::edit
* @see app/Http/Controllers/Admin/PopupController.php:74
* @route '/admin/popups/{popup}/edit'
*/
edit.url = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { popup: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { popup: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            popup: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        popup: typeof args.popup === 'object'
        ? args.popup.id
        : args.popup,
    }

    return edit.definition.url
            .replace('{popup}', parsedArgs.popup.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PopupController::edit
* @see app/Http/Controllers/Admin/PopupController.php:74
* @route '/admin/popups/{popup}/edit'
*/
edit.get = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::edit
* @see app/Http/Controllers/Admin/PopupController.php:74
* @route '/admin/popups/{popup}/edit'
*/
edit.head = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::edit
* @see app/Http/Controllers/Admin/PopupController.php:74
* @route '/admin/popups/{popup}/edit'
*/
const editForm = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::edit
* @see app/Http/Controllers/Admin/PopupController.php:74
* @route '/admin/popups/{popup}/edit'
*/
editForm.get = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::edit
* @see app/Http/Controllers/Admin/PopupController.php:74
* @route '/admin/popups/{popup}/edit'
*/
editForm.head = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\PopupController::update
* @see app/Http/Controllers/Admin/PopupController.php:110
* @route '/admin/popups/{popup}'
*/
export const update = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/popups/{popup}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\PopupController::update
* @see app/Http/Controllers/Admin/PopupController.php:110
* @route '/admin/popups/{popup}'
*/
update.url = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { popup: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { popup: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            popup: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        popup: typeof args.popup === 'object'
        ? args.popup.id
        : args.popup,
    }

    return update.definition.url
            .replace('{popup}', parsedArgs.popup.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PopupController::update
* @see app/Http/Controllers/Admin/PopupController.php:110
* @route '/admin/popups/{popup}'
*/
update.put = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::update
* @see app/Http/Controllers/Admin/PopupController.php:110
* @route '/admin/popups/{popup}'
*/
const updateForm = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::update
* @see app/Http/Controllers/Admin/PopupController.php:110
* @route '/admin/popups/{popup}'
*/
updateForm.put = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\PopupController::destroy
* @see app/Http/Controllers/Admin/PopupController.php:123
* @route '/admin/popups/{popup}'
*/
export const destroy = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/popups/{popup}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\PopupController::destroy
* @see app/Http/Controllers/Admin/PopupController.php:123
* @route '/admin/popups/{popup}'
*/
destroy.url = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { popup: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { popup: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            popup: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        popup: typeof args.popup === 'object'
        ? args.popup.id
        : args.popup,
    }

    return destroy.definition.url
            .replace('{popup}', parsedArgs.popup.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\PopupController::destroy
* @see app/Http/Controllers/Admin/PopupController.php:123
* @route '/admin/popups/{popup}'
*/
destroy.delete = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::destroy
* @see app/Http/Controllers/Admin/PopupController.php:123
* @route '/admin/popups/{popup}'
*/
const destroyForm = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\PopupController::destroy
* @see app/Http/Controllers/Admin/PopupController.php:123
* @route '/admin/popups/{popup}'
*/
destroyForm.delete = (args: { popup: string | number | { id: string | number } } | [popup: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const PopupController = { index, create, store, edit, update, destroy }

export default PopupController
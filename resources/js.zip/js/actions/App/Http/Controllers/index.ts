import Analytics from './Analytics'
import Public from './Public'
import ContentFormula from './ContentFormula'
import Admin from './Admin'
import Settings from './Settings'
import QO from './QO'

const Controllers = {
    Analytics: Object.assign(Analytics, Analytics),
    Public: Object.assign(Public, Public),
    ContentFormula: Object.assign(ContentFormula, ContentFormula),
    Admin: Object.assign(Admin, Admin),
    Settings: Object.assign(Settings, Settings),
    QO: Object.assign(QO, QO),
}

export default Controllers
import IngestController from './IngestController'

const Analytics = {
    IngestController: Object.assign(IngestController, IngestController),
}

export default Analytics
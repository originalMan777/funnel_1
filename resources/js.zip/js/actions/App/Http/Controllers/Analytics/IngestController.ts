import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Analytics\IngestController::__invoke
* @see app/Http/Controllers/Analytics/IngestController.php:20
* @route '/analytics/ingest'
*/
const IngestController = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: IngestController.url(options),
    method: 'post',
})

IngestController.definition = {
    methods: ["post"],
    url: '/analytics/ingest',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Analytics\IngestController::__invoke
* @see app/Http/Controllers/Analytics/IngestController.php:20
* @route '/analytics/ingest'
*/
IngestController.url = (options?: RouteQueryOptions) => {
    return IngestController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Analytics\IngestController::__invoke
* @see app/Http/Controllers/Analytics/IngestController.php:20
* @route '/analytics/ingest'
*/
IngestController.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: IngestController.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Analytics\IngestController::__invoke
* @see app/Http/Controllers/Analytics/IngestController.php:20
* @route '/analytics/ingest'
*/
const IngestControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: IngestController.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Analytics\IngestController::__invoke
* @see app/Http/Controllers/Analytics/IngestController.php:20
* @route '/analytics/ingest'
*/
IngestControllerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: IngestController.url(options),
    method: 'post',
})

IngestController.form = IngestControllerForm

export default IngestController
import LeadController from './LeadController'
import PopupLeadController from './PopupLeadController'
import HomeController from './HomeController'
import MagnetEntryController from './MagnetEntryController'
import PostController from './PostController'

const Public = {
    LeadController: Object.assign(LeadController, LeadController),
    PopupLeadController: Object.assign(PopupLeadController, PopupLeadController),
    HomeController: Object.assign(HomeController, HomeController),
    MagnetEntryController: Object.assign(MagnetEntryController, MagnetEntryController),
    PostController: Object.assign(PostController, PostController),
}

export default Public
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Public\LeadController::storeConsultation
* @see app/Http/Controllers/Public/LeadController.php:325
* @route '/consultation/request'
*/
export const storeConsultation = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeConsultation.url(options),
    method: 'post',
})

storeConsultation.definition = {
    methods: ["post"],
    url: '/consultation/request',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Public\LeadController::storeConsultation
* @see app/Http/Controllers/Public/LeadController.php:325
* @route '/consultation/request'
*/
storeConsultation.url = (options?: RouteQueryOptions) => {
    return storeConsultation.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\LeadController::storeConsultation
* @see app/Http/Controllers/Public/LeadController.php:325
* @route '/consultation/request'
*/
storeConsultation.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeConsultation.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Public\LeadController::storeConsultation
* @see app/Http/Controllers/Public/LeadController.php:325
* @route '/consultation/request'
*/
const storeConsultationForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeConsultation.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Public\LeadController::storeConsultation
* @see app/Http/Controllers/Public/LeadController.php:325
* @route '/consultation/request'
*/
storeConsultationForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeConsultation.url(options),
    method: 'post',
})

storeConsultation.form = storeConsultationForm

/**
* @see \App\Http\Controllers\Public\LeadController::storeContact
* @see app/Http/Controllers/Public/LeadController.php:251
* @route '/contact'
*/
export const storeContact = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeContact.url(options),
    method: 'post',
})

storeContact.definition = {
    methods: ["post"],
    url: '/contact',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Public\LeadController::storeContact
* @see app/Http/Controllers/Public/LeadController.php:251
* @route '/contact'
*/
storeContact.url = (options?: RouteQueryOptions) => {
    return storeContact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\LeadController::storeContact
* @see app/Http/Controllers/Public/LeadController.php:251
* @route '/contact'
*/
storeContact.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeContact.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Public\LeadController::storeContact
* @see app/Http/Controllers/Public/LeadController.php:251
* @route '/contact'
*/
const storeContactForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeContact.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Public\LeadController::storeContact
* @see app/Http/Controllers/Public/LeadController.php:251
* @route '/contact'
*/
storeContactForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeContact.url(options),
    method: 'post',
})

storeContact.form = storeContactForm

/**
* @see \App\Http\Controllers\Public\LeadController::store
* @see app/Http/Controllers/Public/LeadController.php:104
* @route '/leads'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/leads',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Public\LeadController::store
* @see app/Http/Controllers/Public/LeadController.php:104
* @route '/leads'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\LeadController::store
* @see app/Http/Controllers/Public/LeadController.php:104
* @route '/leads'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Public\LeadController::store
* @see app/Http/Controllers/Public/LeadController.php:104
* @route '/leads'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Public\LeadController::store
* @see app/Http/Controllers/Public/LeadController.php:104
* @route '/leads'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const LeadController = { storeConsultation, storeContact, store }

export default LeadController
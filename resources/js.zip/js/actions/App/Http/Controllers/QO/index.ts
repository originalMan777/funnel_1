import QOShowController from './QOShowController'
import QORuntimeController from './QORuntimeController'

const QO = {
    QOShowController: Object.assign(QOShowController, QOShowController),
    QORuntimeController: Object.assign(QORuntimeController, QORuntimeController),
}

export default QO
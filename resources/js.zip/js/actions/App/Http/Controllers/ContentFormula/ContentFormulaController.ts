import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::index
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:29
* @route '/admin/content-formula'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/content-formula',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::index
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:29
* @route '/admin/content-formula'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::index
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:29
* @route '/admin/content-formula'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::index
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:29
* @route '/admin/content-formula'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::index
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:29
* @route '/admin/content-formula'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::index
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:29
* @route '/admin/content-formula'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::index
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:29
* @route '/admin/content-formula'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::generate
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:40
* @route '/admin/content-formula/generate'
*/
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/admin/content-formula/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::generate
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:40
* @route '/admin/content-formula/generate'
*/
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::generate
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:40
* @route '/admin/content-formula/generate'
*/
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::generate
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:40
* @route '/admin/content-formula/generate'
*/
const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::generate
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:40
* @route '/admin/content-formula/generate'
*/
generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generate.url(options),
    method: 'post',
})

generate.form = generateForm

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::config
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:184
* @route '/admin/content-formula/config'
*/
export const config = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(options),
    method: 'get',
})

config.definition = {
    methods: ["get","head"],
    url: '/admin/content-formula/config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::config
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:184
* @route '/admin/content-formula/config'
*/
config.url = (options?: RouteQueryOptions) => {
    return config.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::config
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:184
* @route '/admin/content-formula/config'
*/
config.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::config
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:184
* @route '/admin/content-formula/config'
*/
config.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: config.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::config
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:184
* @route '/admin/content-formula/config'
*/
const configForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: config.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::config
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:184
* @route '/admin/content-formula/config'
*/
configForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: config.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ContentFormula\ContentFormulaController::config
* @see app/Http/Controllers/ContentFormula/ContentFormulaController.php:184
* @route '/admin/content-formula/config'
*/
configForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: config.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

config.form = configForm

const ContentFormulaController = { index, generate, config }

export default ContentFormulaController
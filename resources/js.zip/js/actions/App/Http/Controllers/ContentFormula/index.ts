import ContentFormulaController from './ContentFormulaController'

const ContentFormula = {
    ContentFormulaController: Object.assign(ContentFormulaController, ContentFormulaController),
}

export default ContentFormula
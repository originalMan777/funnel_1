<script setup lang="ts">
import { Head } from '@inertiajs/vue3';
import { computed, ref } from 'vue';
import AdminLayout from '@/AppLayouts/AdminLayout.vue';
import VisualConsoleDisplayNumber from '@/components/admin/analytics/visuals/VisualConsoleDisplayNumber.vue';
import VisualHalfDonutMovingDot from '@/components/admin/analytics/visuals/VisualHalfDonutMovingDot.vue';
import VisualHeavyDonutDistribution from '@/components/admin/analytics/visuals/VisualHeavyDonutDistribution.vue';
import VisualScreenTileNumber from '@/components/admin/analytics/visuals/VisualScreenTileNumber.vue';
import VisualStraightStrengthTrack from '@/components/admin/analytics/visuals/VisualStraightStrengthTrack.vue';
import VisualTacticalDonutDistribution from '@/components/admin/analytics/visuals/VisualTacticalDonutDistribution.vue';

const visualOptions = [
    {
        key: 'screen-tile-number',
        name: 'Screen Tile Number',
        status: 'Accepted',
        purpose: 'Standalone number display for raw totals without judgment language.',
        label: 'Total Leads',
        value: '1,284',
        meta: 'Current captured volume',
        foot: 'Raw number display',
        component: VisualScreenTileNumber,
        data: undefined,
    },
    {
        key: 'console-display-number',
        name: 'Console Display Number',
        status: 'Accepted',
        purpose: 'Operator-style numeric display for a high-signal KPI value.',
        label: 'Pipeline Value',
        value: '$128K',
        meta: 'Qualified opportunity total',
        foot: 'Operator display panel',
        component: VisualConsoleDisplayNumber,
        data: undefined,
    },
    {
        key: 'half-donut-moving-dot',
        name: 'Half Donut — Moving Dot',
        status: 'Accepted',
        purpose: 'Strength indicator where the marker travels across a weak-to-strong arc.',
        label: 'Signal Strength',
        value: '72',
        meta: 'Dot travels across the arc',
        foot: undefined,
        component: VisualHalfDonutMovingDot,
        data: undefined,
    },
    {
        key: 'straight-strength-track',
        name: 'Straight Strength Track / Hard Marker',
        status: 'Accepted',
        purpose: 'Linear weak-to-strong track with a hard marker for direct scanning.',
        label: 'Signal Strength',
        value: '72',
        meta: 'Hard marker across strength track',
        foot: undefined,
        component: VisualStraightStrengthTrack,
        data: undefined,
    },
    {
        key: 'heavy-donut-distribution',
        name: 'Donut — Heavy Segments',
        status: 'Testing',
        purpose: 'Bold distribution visual for comparing source share at a glance.',
        label: 'Traffic Sources',
        value: undefined,
        meta: 'Bold distribution visual',
        foot: undefined,
        component: VisualHeavyDonutDistribution,
        data: [
            { label: 'Google', value: 50, color: '#22c55e' },
            { label: 'Facebook', value: 30, color: '#f59e0b' },
            { label: 'Direct', value: 20, color: '#ef4444' },
        ],
    },
    {
        key: 'tactical-donut-distribution',
        name: 'Donut — Tactical Blocks',
        status: 'Testing',
        purpose: 'Higher-contrast donut candidate for immediate distribution readability.',
        label: 'Traffic Sources',
        value: undefined,
        meta: 'Immediate readability test',
        foot: undefined,
        component: VisualTacticalDonutDistribution,
        data: [
            { label: 'Google', value: 50, color: '#84cc16' },
            { label: 'Facebook', value: 30, color: '#eab308' },
            { label: 'Direct', value: 20, color: '#dc2626' },
        ],
    },
];

const selectedVisualKey = ref(visualOptions[0].key);

const selectedVisual = computed(
    () =>
        visualOptions.find((visual) => visual.key === selectedVisualKey.value) ??
        visualOptions[0],
);
</script>

<template>
    <Head title="Visual Workbench" />

    <AdminLayout>
        <div class="min-h-screen bg-[#f4efe7] px-4 py-6 sm:px-6 lg:px-8">
            <div class="mx-auto max-w-7xl space-y-6">
                <section class="rounded-[1.75rem] border border-stone-300 bg-white px-6 py-8 shadow-sm sm:px-8">
                    <p class="text-[11px] font-semibold uppercase tracking-[0.24em] text-stone-500">
                        Analytics Sandbox
                    </p>

                    <h1 class="mt-3 text-3xl font-semibold tracking-tight text-stone-950 sm:text-4xl">
                        Visual Workbench
                    </h1>

                    <p class="mt-3 max-w-3xl text-sm leading-6 text-stone-600 sm:text-base">
                        Active testing room for one analytics visual at a time.
                    </p>
                </section>

                <section class="grid gap-5 lg:grid-cols-[18rem_1fr]">
                    <aside class="rounded-[1.25rem] border border-slate-200 bg-white p-4 shadow-sm">
                        <p class="px-2 text-[11px] font-bold uppercase tracking-[0.22em] text-slate-500">
                            Visual Selector
                        </p>

                        <div class="mt-4 space-y-2">
                            <button
                                v-for="visual in visualOptions"
                                :key="visual.key"
                                type="button"
                                class="w-full rounded-xl border px-3 py-3 text-left transition"
                                :class="
                                    selectedVisual.key === visual.key
                                        ? 'border-slate-950 bg-slate-950 text-white shadow-sm'
                                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                                "
                                @click="selectedVisualKey = visual.key"
                            >
                                <span class="block text-sm font-semibold">
                                    {{ visual.name }}
                                </span>
                                <span
                                    class="mt-1 block text-[10px] font-bold uppercase tracking-[0.2em]"
                                    :class="selectedVisual.key === visual.key ? 'text-cyan-200' : 'text-slate-400'"
                                >
                                    {{ visual.status }}
                                </span>
                            </button>
                        </div>
                    </aside>

                    <div class="grid gap-5 xl:grid-cols-[1fr_18rem]">
                        <section class="overflow-hidden rounded-[1.5rem] border border-slate-800 bg-slate-950 shadow-2xl">
                            <div class="border-b border-white/10 px-6 py-5">
                                <p class="text-[11px] font-semibold uppercase tracking-[0.24em] text-cyan-300">
                                    Large Preview
                                </p>

                                <h2 class="mt-2 text-2xl font-semibold tracking-tight text-white">
                                    {{ selectedVisual.name }}
                                </h2>
                            </div>

                            <div class="min-h-[36rem] bg-slate-950 p-6">
                                <component
                                    :is="selectedVisual.component"
                                    :data="selectedVisual.data"
                                    :foot="selectedVisual.foot"
                                    :label="selectedVisual.label"
                                    :meta="selectedVisual.meta"
                                    :value="selectedVisual.value"
                                />
                            </div>
                        </section>

                        <aside class="rounded-[1.25rem] border border-slate-200 bg-white p-5 shadow-sm">
                            <p class="text-[11px] font-bold uppercase tracking-[0.22em] text-slate-500">
                                Notes
                            </p>

                            <h3 class="mt-3 text-xl font-semibold tracking-tight text-slate-950">
                                {{ selectedVisual.name }}
                            </h3>

                            <div class="mt-4 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
                                <p class="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">
                                    Status
                                </p>
                                <p class="mt-1 text-sm font-semibold text-slate-950">
                                    {{ selectedVisual.status }}
                                </p>
                            </div>

                            <div class="mt-4 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
                                <p class="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">
                                    Purpose
                                </p>
                                <p class="mt-1 text-sm leading-6 text-slate-700">
                                    {{ selectedVisual.purpose }}
                                </p>
                            </div>
                        </aside>
                    </div>
                </section>
            </div>
        </div>
    </AdminLayout>
</template>

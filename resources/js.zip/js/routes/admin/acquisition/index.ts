import contacts from './contacts'

const acquisition = {
    contacts: Object.assign(contacts, contacts),
}

export default acquisition
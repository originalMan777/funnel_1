import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import contentFormula from './content-formula'
import posts from './posts'
import acquisition from './acquisition'
import communications from './communications'
import analytics from './analytics'
import campaigns from './campaigns'
import campaignEnrollments from './campaign-enrollments'
import blogIndexSections from './blog-index-sections'
import categories from './categories'
import tags from './tags'
import media from './media'
import leadBoxes from './lead-boxes'
import leadSlots from './lead-slots'
import popups from './popups'
import postImporter from './post-importer'
import qo from './qo'
/**
* @see routes/web.php:149
* @route '/admin'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:149
* @route '/admin'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see routes/web.php:149
* @route '/admin'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see routes/web.php:149
* @route '/admin'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see routes/web.php:149
* @route '/admin'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see routes/web.php:149
* @route '/admin'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see routes/web.php:149
* @route '/admin'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see routes/web.php:328
* @route '/admin/coming-soon'
*/
export const comingSoon = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: comingSoon.url(options),
    method: 'get',
})

comingSoon.definition = {
    methods: ["get","head"],
    url: '/admin/coming-soon',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:328
* @route '/admin/coming-soon'
*/
comingSoon.url = (options?: RouteQueryOptions) => {
    return comingSoon.definition.url + queryParams(options)
}

/**
* @see routes/web.php:328
* @route '/admin/coming-soon'
*/
comingSoon.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: comingSoon.url(options),
    method: 'get',
})

/**
* @see routes/web.php:328
* @route '/admin/coming-soon'
*/
comingSoon.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: comingSoon.url(options),
    method: 'head',
})

/**
* @see routes/web.php:328
* @route '/admin/coming-soon'
*/
const comingSoonForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: comingSoon.url(options),
    method: 'get',
})

/**
* @see routes/web.php:328
* @route '/admin/coming-soon'
*/
comingSoonForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: comingSoon.url(options),
    method: 'get',
})

/**
* @see routes/web.php:328
* @route '/admin/coming-soon'
*/
comingSoonForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: comingSoon.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

comingSoon.form = comingSoonForm

const admin = {
    contentFormula: Object.assign(contentFormula, contentFormula),
    posts: Object.assign(posts, posts),
    index: Object.assign(index, index),
    acquisition: Object.assign(acquisition, acquisition),
    communications: Object.assign(communications, communications),
    analytics: Object.assign(analytics, analytics),
    campaigns: Object.assign(campaigns, campaigns),
    campaignEnrollments: Object.assign(campaignEnrollments, campaignEnrollments),
    blogIndexSections: Object.assign(blogIndexSections, blogIndexSections),
    categories: Object.assign(categories, categories),
    tags: Object.assign(tags, tags),
    media: Object.assign(media, media),
    leadBoxes: Object.assign(leadBoxes, leadBoxes),
    leadSlots: Object.assign(leadSlots, leadSlots),
    popups: Object.assign(popups, popups),
    postImporter: Object.assign(postImporter, postImporter),
    comingSoon: Object.assign(comingSoon, comingSoon),
    qo: Object.assign(qo, qo),
}

export default admin
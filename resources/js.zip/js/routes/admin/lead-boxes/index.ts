import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import resource from './resource'
import service from './service'
import offer from './offer'
/**
* @see \App\Http\Controllers\Admin\LeadBoxController::index
* @see app/Http/Controllers/Admin/LeadBoxController.php:20
* @route '/admin/lead-boxes'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/lead-boxes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::index
* @see app/Http/Controllers/Admin/LeadBoxController.php:20
* @route '/admin/lead-boxes'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::index
* @see app/Http/Controllers/Admin/LeadBoxController.php:20
* @route '/admin/lead-boxes'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::index
* @see app/Http/Controllers/Admin/LeadBoxController.php:20
* @route '/admin/lead-boxes'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::index
* @see app/Http/Controllers/Admin/LeadBoxController.php:20
* @route '/admin/lead-boxes'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::index
* @see app/Http/Controllers/Admin/LeadBoxController.php:20
* @route '/admin/lead-boxes'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::index
* @see app/Http/Controllers/Admin/LeadBoxController.php:20
* @route '/admin/lead-boxes'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::create
* @see app/Http/Controllers/Admin/LeadBoxController.php:41
* @route '/admin/lead-boxes/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/lead-boxes/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::create
* @see app/Http/Controllers/Admin/LeadBoxController.php:41
* @route '/admin/lead-boxes/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::create
* @see app/Http/Controllers/Admin/LeadBoxController.php:41
* @route '/admin/lead-boxes/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::create
* @see app/Http/Controllers/Admin/LeadBoxController.php:41
* @route '/admin/lead-boxes/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::create
* @see app/Http/Controllers/Admin/LeadBoxController.php:41
* @route '/admin/lead-boxes/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::create
* @see app/Http/Controllers/Admin/LeadBoxController.php:41
* @route '/admin/lead-boxes/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::create
* @see app/Http/Controllers/Admin/LeadBoxController.php:41
* @route '/admin/lead-boxes/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::edit
* @see app/Http/Controllers/Admin/LeadBoxController.php:52
* @route '/admin/lead-boxes/{leadBox}/edit'
*/
export const edit = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/lead-boxes/{leadBox}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::edit
* @see app/Http/Controllers/Admin/LeadBoxController.php:52
* @route '/admin/lead-boxes/{leadBox}/edit'
*/
edit.url = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leadBox: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { leadBox: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            leadBox: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        leadBox: typeof args.leadBox === 'object'
        ? args.leadBox.id
        : args.leadBox,
    }

    return edit.definition.url
            .replace('{leadBox}', parsedArgs.leadBox.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::edit
* @see app/Http/Controllers/Admin/LeadBoxController.php:52
* @route '/admin/lead-boxes/{leadBox}/edit'
*/
edit.get = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::edit
* @see app/Http/Controllers/Admin/LeadBoxController.php:52
* @route '/admin/lead-boxes/{leadBox}/edit'
*/
edit.head = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::edit
* @see app/Http/Controllers/Admin/LeadBoxController.php:52
* @route '/admin/lead-boxes/{leadBox}/edit'
*/
const editForm = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::edit
* @see app/Http/Controllers/Admin/LeadBoxController.php:52
* @route '/admin/lead-boxes/{leadBox}/edit'
*/
editForm.get = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\LeadBoxController::edit
* @see app/Http/Controllers/Admin/LeadBoxController.php:52
* @route '/admin/lead-boxes/{leadBox}/edit'
*/
editForm.head = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

const leadBoxes = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    edit: Object.assign(edit, edit),
    resource: Object.assign(resource, resource),
    service: Object.assign(service, service),
    offer: Object.assign(offer, offer),
}

export default leadBoxes
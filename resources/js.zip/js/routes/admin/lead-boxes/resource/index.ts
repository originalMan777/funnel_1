import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::create
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:22
* @route '/admin/lead-boxes/resource/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/lead-boxes/resource/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::create
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:22
* @route '/admin/lead-boxes/resource/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::create
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:22
* @route '/admin/lead-boxes/resource/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::create
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:22
* @route '/admin/lead-boxes/resource/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::create
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:22
* @route '/admin/lead-boxes/resource/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::create
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:22
* @route '/admin/lead-boxes/resource/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::create
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:22
* @route '/admin/lead-boxes/resource/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::edit
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:59
* @route '/admin/lead-boxes/resource/{leadBox}/edit'
*/
export const edit = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/lead-boxes/resource/{leadBox}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::edit
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:59
* @route '/admin/lead-boxes/resource/{leadBox}/edit'
*/
edit.url = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leadBox: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { leadBox: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            leadBox: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        leadBox: typeof args.leadBox === 'object'
        ? args.leadBox.id
        : args.leadBox,
    }

    return edit.definition.url
            .replace('{leadBox}', parsedArgs.leadBox.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::edit
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:59
* @route '/admin/lead-boxes/resource/{leadBox}/edit'
*/
edit.get = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::edit
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:59
* @route '/admin/lead-boxes/resource/{leadBox}/edit'
*/
edit.head = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::edit
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:59
* @route '/admin/lead-boxes/resource/{leadBox}/edit'
*/
const editForm = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::edit
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:59
* @route '/admin/lead-boxes/resource/{leadBox}/edit'
*/
editForm.get = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::edit
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:59
* @route '/admin/lead-boxes/resource/{leadBox}/edit'
*/
editForm.head = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::store
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:34
* @route '/admin/lead-boxes/resource'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/lead-boxes/resource',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::store
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:34
* @route '/admin/lead-boxes/resource'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::store
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:34
* @route '/admin/lead-boxes/resource'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::store
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:34
* @route '/admin/lead-boxes/resource'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::store
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:34
* @route '/admin/lead-boxes/resource'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::update
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:83
* @route '/admin/lead-boxes/resource/{leadBox}'
*/
export const update = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/lead-boxes/resource/{leadBox}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::update
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:83
* @route '/admin/lead-boxes/resource/{leadBox}'
*/
update.url = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { leadBox: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { leadBox: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            leadBox: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        leadBox: typeof args.leadBox === 'object'
        ? args.leadBox.id
        : args.leadBox,
    }

    return update.definition.url
            .replace('{leadBox}', parsedArgs.leadBox.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::update
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:83
* @route '/admin/lead-boxes/resource/{leadBox}'
*/
update.put = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::update
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:83
* @route '/admin/lead-boxes/resource/{leadBox}'
*/
const updateForm = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\ResourceLeadBoxController::update
* @see app/Http/Controllers/Admin/ResourceLeadBoxController.php:83
* @route '/admin/lead-boxes/resource/{leadBox}'
*/
updateForm.put = (args: { leadBox: string | number | { id: string | number } } | [leadBox: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const resource = {
    create: Object.assign(create, create),
    edit: Object.assign(edit, edit),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
}

export default resource
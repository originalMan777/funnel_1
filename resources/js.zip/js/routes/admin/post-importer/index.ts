import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::index
* @see app/Http/Controllers/Admin/AiPostImporterController.php:29
* @route '/admin/post-importer'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/post-importer',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::index
* @see app/Http/Controllers/Admin/AiPostImporterController.php:29
* @route '/admin/post-importer'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::index
* @see app/Http/Controllers/Admin/AiPostImporterController.php:29
* @route '/admin/post-importer'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::index
* @see app/Http/Controllers/Admin/AiPostImporterController.php:29
* @route '/admin/post-importer'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::index
* @see app/Http/Controllers/Admin/AiPostImporterController.php:29
* @route '/admin/post-importer'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::index
* @see app/Http/Controllers/Admin/AiPostImporterController.php:29
* @route '/admin/post-importer'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::index
* @see app/Http/Controllers/Admin/AiPostImporterController.php:29
* @route '/admin/post-importer'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::store
* @see app/Http/Controllers/Admin/AiPostImporterController.php:36
* @route '/admin/post-importer'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/post-importer',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::store
* @see app/Http/Controllers/Admin/AiPostImporterController.php:36
* @route '/admin/post-importer'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::store
* @see app/Http/Controllers/Admin/AiPostImporterController.php:36
* @route '/admin/post-importer'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::store
* @see app/Http/Controllers/Admin/AiPostImporterController.php:36
* @route '/admin/post-importer'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\AiPostImporterController::store
* @see app/Http/Controllers/Admin/AiPostImporterController.php:36
* @route '/admin/post-importer'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const postImporter = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
}

export default postImporter
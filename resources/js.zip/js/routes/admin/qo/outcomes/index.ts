import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::store
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:11
* @route '/admin/qo/{itemId}/outcomes'
*/
export const store = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/qo/{itemId}/outcomes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::store
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:11
* @route '/admin/qo/{itemId}/outcomes'
*/
store.url = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { itemId: args }
    }

    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
    }

    return store.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::store
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:11
* @route '/admin/qo/{itemId}/outcomes'
*/
store.post = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::store
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:11
* @route '/admin/qo/{itemId}/outcomes'
*/
const storeForm = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::store
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:11
* @route '/admin/qo/{itemId}/outcomes'
*/
storeForm.post = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::update
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:30
* @route '/admin/qo/{itemId}/outcomes/{outcomeId}'
*/
export const update = (args: { itemId: string | number, outcomeId: string | number } | [itemId: string | number, outcomeId: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/qo/{itemId}/outcomes/{outcomeId}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::update
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:30
* @route '/admin/qo/{itemId}/outcomes/{outcomeId}'
*/
update.url = (args: { itemId: string | number, outcomeId: string | number } | [itemId: string | number, outcomeId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
            outcomeId: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
        outcomeId: args.outcomeId,
    }

    return update.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace('{outcomeId}', parsedArgs.outcomeId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::update
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:30
* @route '/admin/qo/{itemId}/outcomes/{outcomeId}'
*/
update.put = (args: { itemId: string | number, outcomeId: string | number } | [itemId: string | number, outcomeId: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::update
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:30
* @route '/admin/qo/{itemId}/outcomes/{outcomeId}'
*/
const updateForm = (args: { itemId: string | number, outcomeId: string | number } | [itemId: string | number, outcomeId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::update
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:30
* @route '/admin/qo/{itemId}/outcomes/{outcomeId}'
*/
updateForm.put = (args: { itemId: string | number, outcomeId: string | number } | [itemId: string | number, outcomeId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::destroy
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:78
* @route '/admin/qo/{itemId}/outcomes/{outcomeId}'
*/
export const destroy = (args: { itemId: string | number, outcomeId: string | number } | [itemId: string | number, outcomeId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/qo/{itemId}/outcomes/{outcomeId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::destroy
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:78
* @route '/admin/qo/{itemId}/outcomes/{outcomeId}'
*/
destroy.url = (args: { itemId: string | number, outcomeId: string | number } | [itemId: string | number, outcomeId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
            outcomeId: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
        outcomeId: args.outcomeId,
    }

    return destroy.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace('{outcomeId}', parsedArgs.outcomeId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::destroy
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:78
* @route '/admin/qo/{itemId}/outcomes/{outcomeId}'
*/
destroy.delete = (args: { itemId: string | number, outcomeId: string | number } | [itemId: string | number, outcomeId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::destroy
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:78
* @route '/admin/qo/{itemId}/outcomes/{outcomeId}'
*/
const destroyForm = (args: { itemId: string | number, outcomeId: string | number } | [itemId: string | number, outcomeId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOutcomeController::destroy
* @see app/Http/Controllers/Admin/QO/QOOutcomeController.php:78
* @route '/admin/qo/{itemId}/outcomes/{outcomeId}'
*/
destroyForm.delete = (args: { itemId: string | number, outcomeId: string | number } | [itemId: string | number, outcomeId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const outcomes = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default outcomes
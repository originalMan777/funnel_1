import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::store
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:44
* @route '/admin/qo/{itemId}/questions'
*/
export const store = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/qo/{itemId}/questions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::store
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:44
* @route '/admin/qo/{itemId}/questions'
*/
store.url = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { itemId: args }
    }

    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
    }

    return store.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::store
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:44
* @route '/admin/qo/{itemId}/questions'
*/
store.post = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::store
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:44
* @route '/admin/qo/{itemId}/questions'
*/
const storeForm = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::store
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:44
* @route '/admin/qo/{itemId}/questions'
*/
storeForm.post = (args: { itemId: string | number } | [itemId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::update
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:11
* @route '/admin/qo/{itemId}/questions/{questionId}'
*/
export const update = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/qo/{itemId}/questions/{questionId}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::update
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:11
* @route '/admin/qo/{itemId}/questions/{questionId}'
*/
update.url = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
            questionId: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
        questionId: args.questionId,
    }

    return update.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace('{questionId}', parsedArgs.questionId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::update
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:11
* @route '/admin/qo/{itemId}/questions/{questionId}'
*/
update.put = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::update
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:11
* @route '/admin/qo/{itemId}/questions/{questionId}'
*/
const updateForm = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::update
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:11
* @route '/admin/qo/{itemId}/questions/{questionId}'
*/
updateForm.put = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::destroy
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:65
* @route '/admin/qo/{itemId}/questions/{questionId}'
*/
export const destroy = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/qo/{itemId}/questions/{questionId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::destroy
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:65
* @route '/admin/qo/{itemId}/questions/{questionId}'
*/
destroy.url = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
            questionId: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
        questionId: args.questionId,
    }

    return destroy.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace('{questionId}', parsedArgs.questionId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::destroy
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:65
* @route '/admin/qo/{itemId}/questions/{questionId}'
*/
destroy.delete = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::destroy
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:65
* @route '/admin/qo/{itemId}/questions/{questionId}'
*/
const destroyForm = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOQuestionController::destroy
* @see app/Http/Controllers/Admin/QO/QOQuestionController.php:65
* @route '/admin/qo/{itemId}/questions/{questionId}'
*/
destroyForm.delete = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const questions = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default questions
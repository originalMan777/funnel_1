import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::store
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:11
* @route '/admin/qo/{itemId}/questions/{questionId}/options'
*/
export const store = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/qo/{itemId}/questions/{questionId}/options',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::store
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:11
* @route '/admin/qo/{itemId}/questions/{questionId}/options'
*/
store.url = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
            questionId: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
        questionId: args.questionId,
    }

    return store.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace('{questionId}', parsedArgs.questionId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::store
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:11
* @route '/admin/qo/{itemId}/questions/{questionId}/options'
*/
store.post = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::store
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:11
* @route '/admin/qo/{itemId}/questions/{questionId}/options'
*/
const storeForm = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::store
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:11
* @route '/admin/qo/{itemId}/questions/{questionId}/options'
*/
storeForm.post = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::update
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:38
* @route '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}'
*/
export const update = (args: { itemId: string | number, questionId: string | number, optionId: string | number } | [itemId: string | number, questionId: string | number, optionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::update
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:38
* @route '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}'
*/
update.url = (args: { itemId: string | number, questionId: string | number, optionId: string | number } | [itemId: string | number, questionId: string | number, optionId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
            questionId: args[1],
            optionId: args[2],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
        questionId: args.questionId,
        optionId: args.optionId,
    }

    return update.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace('{questionId}', parsedArgs.questionId.toString())
            .replace('{optionId}', parsedArgs.optionId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::update
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:38
* @route '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}'
*/
update.put = (args: { itemId: string | number, questionId: string | number, optionId: string | number } | [itemId: string | number, questionId: string | number, optionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::update
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:38
* @route '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}'
*/
const updateForm = (args: { itemId: string | number, questionId: string | number, optionId: string | number } | [itemId: string | number, questionId: string | number, optionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::update
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:38
* @route '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}'
*/
updateForm.put = (args: { itemId: string | number, questionId: string | number, optionId: string | number } | [itemId: string | number, questionId: string | number, optionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::destroy
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:135
* @route '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}'
*/
export const destroy = (args: { itemId: string | number, questionId: string | number, optionId: string | number } | [itemId: string | number, questionId: string | number, optionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::destroy
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:135
* @route '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}'
*/
destroy.url = (args: { itemId: string | number, questionId: string | number, optionId: string | number } | [itemId: string | number, questionId: string | number, optionId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
            questionId: args[1],
            optionId: args[2],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
        questionId: args.questionId,
        optionId: args.optionId,
    }

    return destroy.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace('{questionId}', parsedArgs.questionId.toString())
            .replace('{optionId}', parsedArgs.optionId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::destroy
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:135
* @route '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}'
*/
destroy.delete = (args: { itemId: string | number, questionId: string | number, optionId: string | number } | [itemId: string | number, questionId: string | number, optionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::destroy
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:135
* @route '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}'
*/
const destroyForm = (args: { itemId: string | number, questionId: string | number, optionId: string | number } | [itemId: string | number, questionId: string | number, optionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::destroy
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:135
* @route '/admin/qo/{itemId}/questions/{questionId}/options/{optionId}'
*/
destroyForm.delete = (args: { itemId: string | number, questionId: string | number, optionId: string | number } | [itemId: string | number, questionId: string | number, optionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::ensureYesNo
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:60
* @route '/admin/qo/{itemId}/questions/{questionId}/options/ensure-yes-no'
*/
export const ensureYesNo = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ensureYesNo.url(args, options),
    method: 'post',
})

ensureYesNo.definition = {
    methods: ["post"],
    url: '/admin/qo/{itemId}/questions/{questionId}/options/ensure-yes-no',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::ensureYesNo
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:60
* @route '/admin/qo/{itemId}/questions/{questionId}/options/ensure-yes-no'
*/
ensureYesNo.url = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
            questionId: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
        questionId: args.questionId,
    }

    return ensureYesNo.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace('{questionId}', parsedArgs.questionId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::ensureYesNo
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:60
* @route '/admin/qo/{itemId}/questions/{questionId}/options/ensure-yes-no'
*/
ensureYesNo.post = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ensureYesNo.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::ensureYesNo
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:60
* @route '/admin/qo/{itemId}/questions/{questionId}/options/ensure-yes-no'
*/
const ensureYesNoForm = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: ensureYesNo.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::ensureYesNo
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:60
* @route '/admin/qo/{itemId}/questions/{questionId}/options/ensure-yes-no'
*/
ensureYesNoForm.post = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: ensureYesNo.url(args, options),
    method: 'post',
})

ensureYesNo.form = ensureYesNoForm

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::resetForType
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:87
* @route '/admin/qo/{itemId}/questions/{questionId}/options/reset-for-type'
*/
export const resetForType = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetForType.url(args, options),
    method: 'post',
})

resetForType.definition = {
    methods: ["post"],
    url: '/admin/qo/{itemId}/questions/{questionId}/options/reset-for-type',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::resetForType
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:87
* @route '/admin/qo/{itemId}/questions/{questionId}/options/reset-for-type'
*/
resetForType.url = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            itemId: args[0],
            questionId: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        itemId: args.itemId,
        questionId: args.questionId,
    }

    return resetForType.definition.url
            .replace('{itemId}', parsedArgs.itemId.toString())
            .replace('{questionId}', parsedArgs.questionId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::resetForType
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:87
* @route '/admin/qo/{itemId}/questions/{questionId}/options/reset-for-type'
*/
resetForType.post = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetForType.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::resetForType
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:87
* @route '/admin/qo/{itemId}/questions/{questionId}/options/reset-for-type'
*/
const resetForTypeForm = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: resetForType.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOOptionController::resetForType
* @see app/Http/Controllers/Admin/QO/QOOptionController.php:87
* @route '/admin/qo/{itemId}/questions/{questionId}/options/reset-for-type'
*/
resetForTypeForm.post = (args: { itemId: string | number, questionId: string | number } | [itemId: string | number, questionId: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: resetForType.url(args, options),
    method: 'post',
})

resetForType.form = resetForTypeForm

const options = {
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
    ensureYesNo: Object.assign(ensureYesNo, ensureYesNo),
    resetForType: Object.assign(resetForType, resetForType),
}

export default options
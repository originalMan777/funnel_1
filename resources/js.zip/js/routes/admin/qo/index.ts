import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import questions from './questions'
import options from './options'
import outcomes from './outcomes'
/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::index
* @see app/Http/Controllers/Admin/QO/QOItemController.php:14
* @route '/admin/qo'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/qo',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::index
* @see app/Http/Controllers/Admin/QO/QOItemController.php:14
* @route '/admin/qo'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::index
* @see app/Http/Controllers/Admin/QO/QOItemController.php:14
* @route '/admin/qo'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::index
* @see app/Http/Controllers/Admin/QO/QOItemController.php:14
* @route '/admin/qo'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::index
* @see app/Http/Controllers/Admin/QO/QOItemController.php:14
* @route '/admin/qo'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::index
* @see app/Http/Controllers/Admin/QO/QOItemController.php:14
* @route '/admin/qo'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::index
* @see app/Http/Controllers/Admin/QO/QOItemController.php:14
* @route '/admin/qo'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::create
* @see app/Http/Controllers/Admin/QO/QOItemController.php:26
* @route '/admin/qo/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/qo/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::create
* @see app/Http/Controllers/Admin/QO/QOItemController.php:26
* @route '/admin/qo/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::create
* @see app/Http/Controllers/Admin/QO/QOItemController.php:26
* @route '/admin/qo/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::create
* @see app/Http/Controllers/Admin/QO/QOItemController.php:26
* @route '/admin/qo/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::create
* @see app/Http/Controllers/Admin/QO/QOItemController.php:26
* @route '/admin/qo/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::create
* @see app/Http/Controllers/Admin/QO/QOItemController.php:26
* @route '/admin/qo/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::create
* @see app/Http/Controllers/Admin/QO/QOItemController.php:26
* @route '/admin/qo/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::store
* @see app/Http/Controllers/Admin/QO/QOItemController.php:33
* @route '/admin/qo'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/qo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::store
* @see app/Http/Controllers/Admin/QO/QOItemController.php:33
* @route '/admin/qo'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::store
* @see app/Http/Controllers/Admin/QO/QOItemController.php:33
* @route '/admin/qo'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::store
* @see app/Http/Controllers/Admin/QO/QOItemController.php:33
* @route '/admin/qo'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::store
* @see app/Http/Controllers/Admin/QO/QOItemController.php:33
* @route '/admin/qo'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::edit
* @see app/Http/Controllers/Admin/QO/QOItemController.php:60
* @route '/admin/qo/{id}/edit'
*/
export const edit = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/qo/{id}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::edit
* @see app/Http/Controllers/Admin/QO/QOItemController.php:60
* @route '/admin/qo/{id}/edit'
*/
edit.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return edit.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::edit
* @see app/Http/Controllers/Admin/QO/QOItemController.php:60
* @route '/admin/qo/{id}/edit'
*/
edit.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::edit
* @see app/Http/Controllers/Admin/QO/QOItemController.php:60
* @route '/admin/qo/{id}/edit'
*/
edit.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::edit
* @see app/Http/Controllers/Admin/QO/QOItemController.php:60
* @route '/admin/qo/{id}/edit'
*/
const editForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::edit
* @see app/Http/Controllers/Admin/QO/QOItemController.php:60
* @route '/admin/qo/{id}/edit'
*/
editForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::edit
* @see app/Http/Controllers/Admin/QO/QOItemController.php:60
* @route '/admin/qo/{id}/edit'
*/
editForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::update
* @see app/Http/Controllers/Admin/QO/QOItemController.php:74
* @route '/admin/qo/{id}'
*/
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/qo/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::update
* @see app/Http/Controllers/Admin/QO/QOItemController.php:74
* @route '/admin/qo/{id}'
*/
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::update
* @see app/Http/Controllers/Admin/QO/QOItemController.php:74
* @route '/admin/qo/{id}'
*/
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::update
* @see app/Http/Controllers/Admin/QO/QOItemController.php:74
* @route '/admin/qo/{id}'
*/
const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::update
* @see app/Http/Controllers/Admin/QO/QOItemController.php:74
* @route '/admin/qo/{id}'
*/
updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::publish
* @see app/Http/Controllers/Admin/QO/QOItemController.php:103
* @route '/admin/qo/{id}/publish'
*/
export const publish = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

publish.definition = {
    methods: ["post"],
    url: '/admin/qo/{id}/publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::publish
* @see app/Http/Controllers/Admin/QO/QOItemController.php:103
* @route '/admin/qo/{id}/publish'
*/
publish.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return publish.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::publish
* @see app/Http/Controllers/Admin/QO/QOItemController.php:103
* @route '/admin/qo/{id}/publish'
*/
publish.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::publish
* @see app/Http/Controllers/Admin/QO/QOItemController.php:103
* @route '/admin/qo/{id}/publish'
*/
const publishForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: publish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::publish
* @see app/Http/Controllers/Admin/QO/QOItemController.php:103
* @route '/admin/qo/{id}/publish'
*/
publishForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: publish.url(args, options),
    method: 'post',
})

publish.form = publishForm

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::unpublish
* @see app/Http/Controllers/Admin/QO/QOItemController.php:123
* @route '/admin/qo/{id}/unpublish'
*/
export const unpublish = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unpublish.url(args, options),
    method: 'post',
})

unpublish.definition = {
    methods: ["post"],
    url: '/admin/qo/{id}/unpublish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::unpublish
* @see app/Http/Controllers/Admin/QO/QOItemController.php:123
* @route '/admin/qo/{id}/unpublish'
*/
unpublish.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return unpublish.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::unpublish
* @see app/Http/Controllers/Admin/QO/QOItemController.php:123
* @route '/admin/qo/{id}/unpublish'
*/
unpublish.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unpublish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::unpublish
* @see app/Http/Controllers/Admin/QO/QOItemController.php:123
* @route '/admin/qo/{id}/unpublish'
*/
const unpublishForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: unpublish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::unpublish
* @see app/Http/Controllers/Admin/QO/QOItemController.php:123
* @route '/admin/qo/{id}/unpublish'
*/
unpublishForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: unpublish.url(args, options),
    method: 'post',
})

unpublish.form = unpublishForm

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::archive
* @see app/Http/Controllers/Admin/QO/QOItemController.php:135
* @route '/admin/qo/{id}/archive'
*/
export const archive = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: archive.url(args, options),
    method: 'post',
})

archive.definition = {
    methods: ["post"],
    url: '/admin/qo/{id}/archive',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::archive
* @see app/Http/Controllers/Admin/QO/QOItemController.php:135
* @route '/admin/qo/{id}/archive'
*/
archive.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return archive.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::archive
* @see app/Http/Controllers/Admin/QO/QOItemController.php:135
* @route '/admin/qo/{id}/archive'
*/
archive.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: archive.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::archive
* @see app/Http/Controllers/Admin/QO/QOItemController.php:135
* @route '/admin/qo/{id}/archive'
*/
const archiveForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: archive.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::archive
* @see app/Http/Controllers/Admin/QO/QOItemController.php:135
* @route '/admin/qo/{id}/archive'
*/
archiveForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: archive.url(args, options),
    method: 'post',
})

archive.form = archiveForm

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::preview
* @see app/Http/Controllers/Admin/QO/QOItemController.php:146
* @route '/admin/qo/{id}/preview'
*/
export const preview = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/admin/qo/{id}/preview',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::preview
* @see app/Http/Controllers/Admin/QO/QOItemController.php:146
* @route '/admin/qo/{id}/preview'
*/
preview.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return preview.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::preview
* @see app/Http/Controllers/Admin/QO/QOItemController.php:146
* @route '/admin/qo/{id}/preview'
*/
preview.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::preview
* @see app/Http/Controllers/Admin/QO/QOItemController.php:146
* @route '/admin/qo/{id}/preview'
*/
preview.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::preview
* @see app/Http/Controllers/Admin/QO/QOItemController.php:146
* @route '/admin/qo/{id}/preview'
*/
const previewForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::preview
* @see app/Http/Controllers/Admin/QO/QOItemController.php:146
* @route '/admin/qo/{id}/preview'
*/
previewForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\QO\QOItemController::preview
* @see app/Http/Controllers/Admin/QO/QOItemController.php:146
* @route '/admin/qo/{id}/preview'
*/
previewForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: preview.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

preview.form = previewForm

const qo = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    publish: Object.assign(publish, publish),
    unpublish: Object.assign(unpublish, unpublish),
    archive: Object.assign(archive, archive),
    questions: Object.assign(questions, questions),
    options: Object.assign(options, options),
    outcomes: Object.assign(outcomes, outcomes),
    preview: Object.assign(preview, preview),
}

export default qo
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CampaignController::index
* @see app/Http/Controllers/Admin/CampaignController.php:23
* @route '/admin/campaigns'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/campaigns',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CampaignController::index
* @see app/Http/Controllers/Admin/CampaignController.php:23
* @route '/admin/campaigns'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CampaignController::index
* @see app/Http/Controllers/Admin/CampaignController.php:23
* @route '/admin/campaigns'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::index
* @see app/Http/Controllers/Admin/CampaignController.php:23
* @route '/admin/campaigns'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::index
* @see app/Http/Controllers/Admin/CampaignController.php:23
* @route '/admin/campaigns'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::index
* @see app/Http/Controllers/Admin/CampaignController.php:23
* @route '/admin/campaigns'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::index
* @see app/Http/Controllers/Admin/CampaignController.php:23
* @route '/admin/campaigns'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\CampaignController::create
* @see app/Http/Controllers/Admin/CampaignController.php:46
* @route '/admin/campaigns/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/campaigns/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CampaignController::create
* @see app/Http/Controllers/Admin/CampaignController.php:46
* @route '/admin/campaigns/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CampaignController::create
* @see app/Http/Controllers/Admin/CampaignController.php:46
* @route '/admin/campaigns/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::create
* @see app/Http/Controllers/Admin/CampaignController.php:46
* @route '/admin/campaigns/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::create
* @see app/Http/Controllers/Admin/CampaignController.php:46
* @route '/admin/campaigns/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::create
* @see app/Http/Controllers/Admin/CampaignController.php:46
* @route '/admin/campaigns/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::create
* @see app/Http/Controllers/Admin/CampaignController.php:46
* @route '/admin/campaigns/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\CampaignController::store
* @see app/Http/Controllers/Admin/CampaignController.php:53
* @route '/admin/campaigns'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/campaigns',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CampaignController::store
* @see app/Http/Controllers/Admin/CampaignController.php:53
* @route '/admin/campaigns'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CampaignController::store
* @see app/Http/Controllers/Admin/CampaignController.php:53
* @route '/admin/campaigns'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::store
* @see app/Http/Controllers/Admin/CampaignController.php:53
* @route '/admin/campaigns'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::store
* @see app/Http/Controllers/Admin/CampaignController.php:53
* @route '/admin/campaigns'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\CampaignController::edit
* @see app/Http/Controllers/Admin/CampaignController.php:75
* @route '/admin/campaigns/{campaign}/edit'
*/
export const edit = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/campaigns/{campaign}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CampaignController::edit
* @see app/Http/Controllers/Admin/CampaignController.php:75
* @route '/admin/campaigns/{campaign}/edit'
*/
edit.url = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { campaign: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { campaign: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            campaign: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        campaign: typeof args.campaign === 'object'
        ? args.campaign.id
        : args.campaign,
    }

    return edit.definition.url
            .replace('{campaign}', parsedArgs.campaign.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CampaignController::edit
* @see app/Http/Controllers/Admin/CampaignController.php:75
* @route '/admin/campaigns/{campaign}/edit'
*/
edit.get = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::edit
* @see app/Http/Controllers/Admin/CampaignController.php:75
* @route '/admin/campaigns/{campaign}/edit'
*/
edit.head = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::edit
* @see app/Http/Controllers/Admin/CampaignController.php:75
* @route '/admin/campaigns/{campaign}/edit'
*/
const editForm = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::edit
* @see app/Http/Controllers/Admin/CampaignController.php:75
* @route '/admin/campaigns/{campaign}/edit'
*/
editForm.get = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::edit
* @see app/Http/Controllers/Admin/CampaignController.php:75
* @route '/admin/campaigns/{campaign}/edit'
*/
editForm.head = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\CampaignController::update
* @see app/Http/Controllers/Admin/CampaignController.php:110
* @route '/admin/campaigns/{campaign}'
*/
export const update = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/campaigns/{campaign}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\CampaignController::update
* @see app/Http/Controllers/Admin/CampaignController.php:110
* @route '/admin/campaigns/{campaign}'
*/
update.url = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { campaign: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { campaign: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            campaign: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        campaign: typeof args.campaign === 'object'
        ? args.campaign.id
        : args.campaign,
    }

    return update.definition.url
            .replace('{campaign}', parsedArgs.campaign.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CampaignController::update
* @see app/Http/Controllers/Admin/CampaignController.php:110
* @route '/admin/campaigns/{campaign}'
*/
update.put = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::update
* @see app/Http/Controllers/Admin/CampaignController.php:110
* @route '/admin/campaigns/{campaign}'
*/
const updateForm = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CampaignController::update
* @see app/Http/Controllers/Admin/CampaignController.php:110
* @route '/admin/campaigns/{campaign}'
*/
updateForm.put = (args: { campaign: string | number | { id: string | number } } | [campaign: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const campaigns = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
}

export default campaigns
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::index
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:14
* @route '/admin/blog-index-sections'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/blog-index-sections',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::index
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:14
* @route '/admin/blog-index-sections'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::index
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:14
* @route '/admin/blog-index-sections'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::index
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:14
* @route '/admin/blog-index-sections'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::index
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:14
* @route '/admin/blog-index-sections'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::index
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:14
* @route '/admin/blog-index-sections'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::index
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:14
* @route '/admin/blog-index-sections'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::update
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:33
* @route '/admin/blog-index-sections'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/blog-index-sections',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::update
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:33
* @route '/admin/blog-index-sections'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::update
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:33
* @route '/admin/blog-index-sections'
*/
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::update
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:33
* @route '/admin/blog-index-sections'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\BlogIndexSectionController::update
* @see app/Http/Controllers/Admin/BlogIndexSectionController.php:33
* @route '/admin/blog-index-sections'
*/
updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const blogIndexSections = {
    index: Object.assign(index, index),
    update: Object.assign(update, update),
}

export default blogIndexSections
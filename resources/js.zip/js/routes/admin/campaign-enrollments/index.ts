import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::index
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:25
* @route '/admin/campaign-enrollments'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/campaign-enrollments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::index
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:25
* @route '/admin/campaign-enrollments'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::index
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:25
* @route '/admin/campaign-enrollments'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::index
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:25
* @route '/admin/campaign-enrollments'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::index
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:25
* @route '/admin/campaign-enrollments'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::index
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:25
* @route '/admin/campaign-enrollments'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::index
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:25
* @route '/admin/campaign-enrollments'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::show
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:84
* @route '/admin/campaign-enrollments/{campaignEnrollment}'
*/
export const show = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/campaign-enrollments/{campaignEnrollment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::show
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:84
* @route '/admin/campaign-enrollments/{campaignEnrollment}'
*/
show.url = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { campaignEnrollment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { campaignEnrollment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            campaignEnrollment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        campaignEnrollment: typeof args.campaignEnrollment === 'object'
        ? args.campaignEnrollment.id
        : args.campaignEnrollment,
    }

    return show.definition.url
            .replace('{campaignEnrollment}', parsedArgs.campaignEnrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::show
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:84
* @route '/admin/campaign-enrollments/{campaignEnrollment}'
*/
show.get = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::show
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:84
* @route '/admin/campaign-enrollments/{campaignEnrollment}'
*/
show.head = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::show
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:84
* @route '/admin/campaign-enrollments/{campaignEnrollment}'
*/
const showForm = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::show
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:84
* @route '/admin/campaign-enrollments/{campaignEnrollment}'
*/
showForm.get = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::show
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:84
* @route '/admin/campaign-enrollments/{campaignEnrollment}'
*/
showForm.head = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::pause
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:125
* @route '/admin/campaign-enrollments/{campaignEnrollment}/pause'
*/
export const pause = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pause.url(args, options),
    method: 'post',
})

pause.definition = {
    methods: ["post"],
    url: '/admin/campaign-enrollments/{campaignEnrollment}/pause',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::pause
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:125
* @route '/admin/campaign-enrollments/{campaignEnrollment}/pause'
*/
pause.url = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { campaignEnrollment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { campaignEnrollment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            campaignEnrollment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        campaignEnrollment: typeof args.campaignEnrollment === 'object'
        ? args.campaignEnrollment.id
        : args.campaignEnrollment,
    }

    return pause.definition.url
            .replace('{campaignEnrollment}', parsedArgs.campaignEnrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::pause
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:125
* @route '/admin/campaign-enrollments/{campaignEnrollment}/pause'
*/
pause.post = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pause.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::pause
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:125
* @route '/admin/campaign-enrollments/{campaignEnrollment}/pause'
*/
const pauseForm = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pause.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::pause
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:125
* @route '/admin/campaign-enrollments/{campaignEnrollment}/pause'
*/
pauseForm.post = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: pause.url(args, options),
    method: 'post',
})

pause.form = pauseForm

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::resume
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:150
* @route '/admin/campaign-enrollments/{campaignEnrollment}/resume'
*/
export const resume = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(args, options),
    method: 'post',
})

resume.definition = {
    methods: ["post"],
    url: '/admin/campaign-enrollments/{campaignEnrollment}/resume',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::resume
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:150
* @route '/admin/campaign-enrollments/{campaignEnrollment}/resume'
*/
resume.url = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { campaignEnrollment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { campaignEnrollment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            campaignEnrollment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        campaignEnrollment: typeof args.campaignEnrollment === 'object'
        ? args.campaignEnrollment.id
        : args.campaignEnrollment,
    }

    return resume.definition.url
            .replace('{campaignEnrollment}', parsedArgs.campaignEnrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::resume
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:150
* @route '/admin/campaign-enrollments/{campaignEnrollment}/resume'
*/
resume.post = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resume.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::resume
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:150
* @route '/admin/campaign-enrollments/{campaignEnrollment}/resume'
*/
const resumeForm = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: resume.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::resume
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:150
* @route '/admin/campaign-enrollments/{campaignEnrollment}/resume'
*/
resumeForm.post = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: resume.url(args, options),
    method: 'post',
})

resume.form = resumeForm

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::exit
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:175
* @route '/admin/campaign-enrollments/{campaignEnrollment}/exit'
*/
export const exit = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exit.url(args, options),
    method: 'post',
})

exit.definition = {
    methods: ["post"],
    url: '/admin/campaign-enrollments/{campaignEnrollment}/exit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::exit
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:175
* @route '/admin/campaign-enrollments/{campaignEnrollment}/exit'
*/
exit.url = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { campaignEnrollment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { campaignEnrollment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            campaignEnrollment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        campaignEnrollment: typeof args.campaignEnrollment === 'object'
        ? args.campaignEnrollment.id
        : args.campaignEnrollment,
    }

    return exit.definition.url
            .replace('{campaignEnrollment}', parsedArgs.campaignEnrollment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::exit
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:175
* @route '/admin/campaign-enrollments/{campaignEnrollment}/exit'
*/
exit.post = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::exit
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:175
* @route '/admin/campaign-enrollments/{campaignEnrollment}/exit'
*/
const exitForm = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CampaignEnrollmentController::exit
* @see app/Http/Controllers/Admin/CampaignEnrollmentController.php:175
* @route '/admin/campaign-enrollments/{campaignEnrollment}/exit'
*/
exitForm.post = (args: { campaignEnrollment: string | number | { id: string | number } } | [campaignEnrollment: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: exit.url(args, options),
    method: 'post',
})

exit.form = exitForm

const campaignEnrollments = {
    index: Object.assign(index, index),
    show: Object.assign(show, show),
    pause: Object.assign(pause, pause),
    resume: Object.assign(resume, resume),
    exit: Object.assign(exit, exit),
}

export default campaignEnrollments
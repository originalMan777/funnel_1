import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
import versions from './versions'
/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::index
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:22
* @route '/admin/communications/templates'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/communications/templates',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::index
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:22
* @route '/admin/communications/templates'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::index
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:22
* @route '/admin/communications/templates'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::index
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:22
* @route '/admin/communications/templates'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::index
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:22
* @route '/admin/communications/templates'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::index
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:22
* @route '/admin/communications/templates'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::index
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:22
* @route '/admin/communications/templates'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::create
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:55
* @route '/admin/communications/templates/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/communications/templates/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::create
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:55
* @route '/admin/communications/templates/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::create
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:55
* @route '/admin/communications/templates/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::create
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:55
* @route '/admin/communications/templates/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::create
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:55
* @route '/admin/communications/templates/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::create
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:55
* @route '/admin/communications/templates/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::create
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:55
* @route '/admin/communications/templates/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:62
* @route '/admin/communications/templates'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/communications/templates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:62
* @route '/admin/communications/templates'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:62
* @route '/admin/communications/templates'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:62
* @route '/admin/communications/templates'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::store
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:62
* @route '/admin/communications/templates'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::show
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:86
* @route '/admin/communications/templates/{template}'
*/
export const show = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/communications/templates/{template}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::show
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:86
* @route '/admin/communications/templates/{template}'
*/
show.url = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { template: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            template: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return show.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::show
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:86
* @route '/admin/communications/templates/{template}'
*/
show.get = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::show
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:86
* @route '/admin/communications/templates/{template}'
*/
show.head = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::show
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:86
* @route '/admin/communications/templates/{template}'
*/
const showForm = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::show
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:86
* @route '/admin/communications/templates/{template}'
*/
showForm.get = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::show
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:86
* @route '/admin/communications/templates/{template}'
*/
showForm.head = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::edit
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:148
* @route '/admin/communications/templates/{template}/edit'
*/
export const edit = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/communications/templates/{template}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::edit
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:148
* @route '/admin/communications/templates/{template}/edit'
*/
edit.url = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { template: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            template: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return edit.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::edit
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:148
* @route '/admin/communications/templates/{template}/edit'
*/
edit.get = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::edit
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:148
* @route '/admin/communications/templates/{template}/edit'
*/
edit.head = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::edit
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:148
* @route '/admin/communications/templates/{template}/edit'
*/
const editForm = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::edit
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:148
* @route '/admin/communications/templates/{template}/edit'
*/
editForm.get = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::edit
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:148
* @route '/admin/communications/templates/{template}/edit'
*/
editForm.head = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: edit.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

edit.form = editForm

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::update
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:229
* @route '/admin/communications/templates/{template}'
*/
export const update = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/communications/templates/{template}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::update
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:229
* @route '/admin/communications/templates/{template}'
*/
update.url = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { template: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            template: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return update.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::update
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:229
* @route '/admin/communications/templates/{template}'
*/
update.put = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::update
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:229
* @route '/admin/communications/templates/{template}'
*/
const updateForm = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateController::update
* @see app/Http/Controllers/Admin/CommunicationTemplateController.php:229
* @route '/admin/communications/templates/{template}'
*/
updateForm.put = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplatePreviewController::preview
* @see app/Http/Controllers/Admin/CommunicationTemplatePreviewController.php:19
* @route '/admin/communications/templates/{template}/preview'
*/
export const preview = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: preview.url(args, options),
    method: 'post',
})

preview.definition = {
    methods: ["post"],
    url: '/admin/communications/templates/{template}/preview',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplatePreviewController::preview
* @see app/Http/Controllers/Admin/CommunicationTemplatePreviewController.php:19
* @route '/admin/communications/templates/{template}/preview'
*/
preview.url = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { template: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            template: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return preview.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplatePreviewController::preview
* @see app/Http/Controllers/Admin/CommunicationTemplatePreviewController.php:19
* @route '/admin/communications/templates/{template}/preview'
*/
preview.post = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: preview.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplatePreviewController::preview
* @see app/Http/Controllers/Admin/CommunicationTemplatePreviewController.php:19
* @route '/admin/communications/templates/{template}/preview'
*/
const previewForm = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: preview.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplatePreviewController::preview
* @see app/Http/Controllers/Admin/CommunicationTemplatePreviewController.php:19
* @route '/admin/communications/templates/{template}/preview'
*/
previewForm.post = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: preview.url(args, options),
    method: 'post',
})

preview.form = previewForm

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateTestSendController::testSend
* @see app/Http/Controllers/Admin/CommunicationTemplateTestSendController.php:19
* @route '/admin/communications/templates/{template}/test-send'
*/
export const testSend = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testSend.url(args, options),
    method: 'post',
})

testSend.definition = {
    methods: ["post"],
    url: '/admin/communications/templates/{template}/test-send',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateTestSendController::testSend
* @see app/Http/Controllers/Admin/CommunicationTemplateTestSendController.php:19
* @route '/admin/communications/templates/{template}/test-send'
*/
testSend.url = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { template: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { template: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            template: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        template: typeof args.template === 'object'
        ? args.template.id
        : args.template,
    }

    return testSend.definition.url
            .replace('{template}', parsedArgs.template.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateTestSendController::testSend
* @see app/Http/Controllers/Admin/CommunicationTemplateTestSendController.php:19
* @route '/admin/communications/templates/{template}/test-send'
*/
testSend.post = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testSend.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateTestSendController::testSend
* @see app/Http/Controllers/Admin/CommunicationTemplateTestSendController.php:19
* @route '/admin/communications/templates/{template}/test-send'
*/
const testSendForm = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: testSend.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationTemplateTestSendController::testSend
* @see app/Http/Controllers/Admin/CommunicationTemplateTestSendController.php:19
* @route '/admin/communications/templates/{template}/test-send'
*/
testSendForm.post = (args: { template: string | number | { id: string | number } } | [template: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: testSend.url(args, options),
    method: 'post',
})

testSend.form = testSendForm

const templates = {
    index: Object.assign(index, index),
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    show: Object.assign(show, show),
    edit: Object.assign(edit, edit),
    update: Object.assign(update, update),
    versions: Object.assign(versions, versions),
    preview: Object.assign(preview, preview),
    testSend: Object.assign(testSend, testSend),
}

export default templates
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import events from './events'
import deliveries from './deliveries'
import syncs from './syncs'
import settings from './settings'
import composer from './composer'
import templates from './templates'
/**
* @see \App\Http\Controllers\Admin\CommunicationOverviewController::index
* @see app/Http/Controllers/Admin/CommunicationOverviewController.php:21
* @route '/admin/communications'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/communications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationOverviewController::index
* @see app/Http/Controllers/Admin/CommunicationOverviewController.php:21
* @route '/admin/communications'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationOverviewController::index
* @see app/Http/Controllers/Admin/CommunicationOverviewController.php:21
* @route '/admin/communications'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationOverviewController::index
* @see app/Http/Controllers/Admin/CommunicationOverviewController.php:21
* @route '/admin/communications'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationOverviewController::index
* @see app/Http/Controllers/Admin/CommunicationOverviewController.php:21
* @route '/admin/communications'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationOverviewController::index
* @see app/Http/Controllers/Admin/CommunicationOverviewController.php:21
* @route '/admin/communications'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationOverviewController::index
* @see app/Http/Controllers/Admin/CommunicationOverviewController.php:21
* @route '/admin/communications'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const communications = {
    index: Object.assign(index, index),
    events: Object.assign(events, events),
    deliveries: Object.assign(deliveries, deliveries),
    syncs: Object.assign(syncs, syncs),
    settings: Object.assign(settings, settings),
    composer: Object.assign(composer, composer),
    templates: Object.assign(templates, templates),
}

export default communications
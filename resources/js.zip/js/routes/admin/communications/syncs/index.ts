import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::index
* @see app/Http/Controllers/Admin/MarketingSyncController.php:15
* @route '/admin/communications/syncs'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/communications/syncs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::index
* @see app/Http/Controllers/Admin/MarketingSyncController.php:15
* @route '/admin/communications/syncs'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::index
* @see app/Http/Controllers/Admin/MarketingSyncController.php:15
* @route '/admin/communications/syncs'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::index
* @see app/Http/Controllers/Admin/MarketingSyncController.php:15
* @route '/admin/communications/syncs'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::index
* @see app/Http/Controllers/Admin/MarketingSyncController.php:15
* @route '/admin/communications/syncs'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::index
* @see app/Http/Controllers/Admin/MarketingSyncController.php:15
* @route '/admin/communications/syncs'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::index
* @see app/Http/Controllers/Admin/MarketingSyncController.php:15
* @route '/admin/communications/syncs'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::show
* @see app/Http/Controllers/Admin/MarketingSyncController.php:65
* @route '/admin/communications/syncs/{marketingContactSync}'
*/
export const show = (args: { marketingContactSync: string | number | { id: string | number } } | [marketingContactSync: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/communications/syncs/{marketingContactSync}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::show
* @see app/Http/Controllers/Admin/MarketingSyncController.php:65
* @route '/admin/communications/syncs/{marketingContactSync}'
*/
show.url = (args: { marketingContactSync: string | number | { id: string | number } } | [marketingContactSync: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { marketingContactSync: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { marketingContactSync: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            marketingContactSync: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        marketingContactSync: typeof args.marketingContactSync === 'object'
        ? args.marketingContactSync.id
        : args.marketingContactSync,
    }

    return show.definition.url
            .replace('{marketingContactSync}', parsedArgs.marketingContactSync.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::show
* @see app/Http/Controllers/Admin/MarketingSyncController.php:65
* @route '/admin/communications/syncs/{marketingContactSync}'
*/
show.get = (args: { marketingContactSync: string | number | { id: string | number } } | [marketingContactSync: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::show
* @see app/Http/Controllers/Admin/MarketingSyncController.php:65
* @route '/admin/communications/syncs/{marketingContactSync}'
*/
show.head = (args: { marketingContactSync: string | number | { id: string | number } } | [marketingContactSync: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::show
* @see app/Http/Controllers/Admin/MarketingSyncController.php:65
* @route '/admin/communications/syncs/{marketingContactSync}'
*/
const showForm = (args: { marketingContactSync: string | number | { id: string | number } } | [marketingContactSync: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::show
* @see app/Http/Controllers/Admin/MarketingSyncController.php:65
* @route '/admin/communications/syncs/{marketingContactSync}'
*/
showForm.get = (args: { marketingContactSync: string | number | { id: string | number } } | [marketingContactSync: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\MarketingSyncController::show
* @see app/Http/Controllers/Admin/MarketingSyncController.php:65
* @route '/admin/communications/syncs/{marketingContactSync}'
*/
showForm.head = (args: { marketingContactSync: string | number | { id: string | number } } | [marketingContactSync: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const syncs = {
    index: Object.assign(index, index),
    show: Object.assign(show, show),
}

export default syncs
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::index
* @see app/Http/Controllers/Admin/CommunicationEventController.php:22
* @route '/admin/communications/events'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/communications/events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::index
* @see app/Http/Controllers/Admin/CommunicationEventController.php:22
* @route '/admin/communications/events'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::index
* @see app/Http/Controllers/Admin/CommunicationEventController.php:22
* @route '/admin/communications/events'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::index
* @see app/Http/Controllers/Admin/CommunicationEventController.php:22
* @route '/admin/communications/events'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::index
* @see app/Http/Controllers/Admin/CommunicationEventController.php:22
* @route '/admin/communications/events'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::index
* @see app/Http/Controllers/Admin/CommunicationEventController.php:22
* @route '/admin/communications/events'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::index
* @see app/Http/Controllers/Admin/CommunicationEventController.php:22
* @route '/admin/communications/events'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::show
* @see app/Http/Controllers/Admin/CommunicationEventController.php:64
* @route '/admin/communications/events/{communicationEvent}'
*/
export const show = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/communications/events/{communicationEvent}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::show
* @see app/Http/Controllers/Admin/CommunicationEventController.php:64
* @route '/admin/communications/events/{communicationEvent}'
*/
show.url = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { communicationEvent: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { communicationEvent: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            communicationEvent: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        communicationEvent: typeof args.communicationEvent === 'object'
        ? args.communicationEvent.id
        : args.communicationEvent,
    }

    return show.definition.url
            .replace('{communicationEvent}', parsedArgs.communicationEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::show
* @see app/Http/Controllers/Admin/CommunicationEventController.php:64
* @route '/admin/communications/events/{communicationEvent}'
*/
show.get = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::show
* @see app/Http/Controllers/Admin/CommunicationEventController.php:64
* @route '/admin/communications/events/{communicationEvent}'
*/
show.head = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::show
* @see app/Http/Controllers/Admin/CommunicationEventController.php:64
* @route '/admin/communications/events/{communicationEvent}'
*/
const showForm = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::show
* @see app/Http/Controllers/Admin/CommunicationEventController.php:64
* @route '/admin/communications/events/{communicationEvent}'
*/
showForm.get = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::show
* @see app/Http/Controllers/Admin/CommunicationEventController.php:64
* @route '/admin/communications/events/{communicationEvent}'
*/
showForm.head = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::requeue
* @see app/Http/Controllers/Admin/CommunicationEventController.php:104
* @route '/admin/communications/events/{communicationEvent}/requeue'
*/
export const requeue = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requeue.url(args, options),
    method: 'post',
})

requeue.definition = {
    methods: ["post"],
    url: '/admin/communications/events/{communicationEvent}/requeue',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::requeue
* @see app/Http/Controllers/Admin/CommunicationEventController.php:104
* @route '/admin/communications/events/{communicationEvent}/requeue'
*/
requeue.url = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { communicationEvent: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { communicationEvent: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            communicationEvent: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        communicationEvent: typeof args.communicationEvent === 'object'
        ? args.communicationEvent.id
        : args.communicationEvent,
    }

    return requeue.definition.url
            .replace('{communicationEvent}', parsedArgs.communicationEvent.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::requeue
* @see app/Http/Controllers/Admin/CommunicationEventController.php:104
* @route '/admin/communications/events/{communicationEvent}/requeue'
*/
requeue.post = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requeue.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::requeue
* @see app/Http/Controllers/Admin/CommunicationEventController.php:104
* @route '/admin/communications/events/{communicationEvent}/requeue'
*/
const requeueForm = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: requeue.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\CommunicationEventController::requeue
* @see app/Http/Controllers/Admin/CommunicationEventController.php:104
* @route '/admin/communications/events/{communicationEvent}/requeue'
*/
requeueForm.post = (args: { communicationEvent: string | number | { id: string | number } } | [communicationEvent: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: requeue.url(args, options),
    method: 'post',
})

requeue.form = requeueForm

const events = {
    index: Object.assign(index, index),
    show: Object.assign(show, show),
    requeue: Object.assign(requeue, requeue),
}

export default events
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:84
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}/{metricGroupKey}'
*/
export const show = (args: { clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number } | [clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/analytics/clusters/{clusterKey}/{subClusterKey}/{metricGroupKey}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:84
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}/{metricGroupKey}'
*/
show.url = (args: { clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number } | [clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            clusterKey: args[0],
            subClusterKey: args[1],
            metricGroupKey: args[2],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        clusterKey: args.clusterKey,
        subClusterKey: args.subClusterKey,
        metricGroupKey: args.metricGroupKey,
    }

    return show.definition.url
            .replace('{clusterKey}', parsedArgs.clusterKey.toString())
            .replace('{subClusterKey}', parsedArgs.subClusterKey.toString())
            .replace('{metricGroupKey}', parsedArgs.metricGroupKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:84
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}/{metricGroupKey}'
*/
show.get = (args: { clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number } | [clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:84
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}/{metricGroupKey}'
*/
show.head = (args: { clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number } | [clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:84
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}/{metricGroupKey}'
*/
const showForm = (args: { clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number } | [clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:84
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}/{metricGroupKey}'
*/
showForm.get = (args: { clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number } | [clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:84
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}/{metricGroupKey}'
*/
showForm.head = (args: { clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number } | [clusterKey: string | number, subClusterKey: string | number, metricGroupKey: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const metricGroups = {
    show: Object.assign(show, show),
}

export default metricGroups
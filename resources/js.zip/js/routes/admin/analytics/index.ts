import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import metrics from './metrics'
import clusters from './clusters'
import metricGroups from './metric-groups'
import subClusters from './sub-clusters'
import funnels from './funnels'
import scenarios from './scenarios'
import pages from './pages'
import ctas from './ctas'
import leadBoxes from './lead-boxes'
import popups from './popups'
import conversions from './conversions'
import attribution from './attribution'
/**
* @see \App\Http\Controllers\Admin\Analytics\OverviewController::index
* @see app/Http/Controllers/Admin/Analytics/OverviewController.php:40
* @route '/admin/analytics'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/analytics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\Analytics\OverviewController::index
* @see app/Http/Controllers/Admin/Analytics/OverviewController.php:40
* @route '/admin/analytics'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\Analytics\OverviewController::index
* @see app/Http/Controllers/Admin/Analytics/OverviewController.php:40
* @route '/admin/analytics'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\OverviewController::index
* @see app/Http/Controllers/Admin/Analytics/OverviewController.php:40
* @route '/admin/analytics'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\OverviewController::index
* @see app/Http/Controllers/Admin/Analytics/OverviewController.php:40
* @route '/admin/analytics'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\OverviewController::index
* @see app/Http/Controllers/Admin/Analytics/OverviewController.php:40
* @route '/admin/analytics'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\OverviewController::index
* @see app/Http/Controllers/Admin/Analytics/OverviewController.php:40
* @route '/admin/analytics'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::graphicsLab
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:54
* @route '/admin/analytics/graphics-lab'
*/
export const graphicsLab = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: graphicsLab.url(options),
    method: 'get',
})

graphicsLab.definition = {
    methods: ["get","head"],
    url: '/admin/analytics/graphics-lab',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::graphicsLab
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:54
* @route '/admin/analytics/graphics-lab'
*/
graphicsLab.url = (options?: RouteQueryOptions) => {
    return graphicsLab.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::graphicsLab
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:54
* @route '/admin/analytics/graphics-lab'
*/
graphicsLab.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: graphicsLab.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::graphicsLab
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:54
* @route '/admin/analytics/graphics-lab'
*/
graphicsLab.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: graphicsLab.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::graphicsLab
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:54
* @route '/admin/analytics/graphics-lab'
*/
const graphicsLabForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: graphicsLab.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::graphicsLab
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:54
* @route '/admin/analytics/graphics-lab'
*/
graphicsLabForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: graphicsLab.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::graphicsLab
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:54
* @route '/admin/analytics/graphics-lab'
*/
graphicsLabForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: graphicsLab.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

graphicsLab.form = graphicsLabForm

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::visualWorkbench
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:59
* @route '/admin/analytics/visual-workbench'
*/
export const visualWorkbench = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: visualWorkbench.url(options),
    method: 'get',
})

visualWorkbench.definition = {
    methods: ["get","head"],
    url: '/admin/analytics/visual-workbench',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::visualWorkbench
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:59
* @route '/admin/analytics/visual-workbench'
*/
visualWorkbench.url = (options?: RouteQueryOptions) => {
    return visualWorkbench.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::visualWorkbench
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:59
* @route '/admin/analytics/visual-workbench'
*/
visualWorkbench.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: visualWorkbench.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::visualWorkbench
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:59
* @route '/admin/analytics/visual-workbench'
*/
visualWorkbench.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: visualWorkbench.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::visualWorkbench
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:59
* @route '/admin/analytics/visual-workbench'
*/
const visualWorkbenchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: visualWorkbench.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::visualWorkbench
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:59
* @route '/admin/analytics/visual-workbench'
*/
visualWorkbenchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: visualWorkbench.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::visualWorkbench
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:59
* @route '/admin/analytics/visual-workbench'
*/
visualWorkbenchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: visualWorkbench.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

visualWorkbench.form = visualWorkbenchForm

const analytics = {
    index: Object.assign(index, index),
    metrics: Object.assign(metrics, metrics),
    graphicsLab: Object.assign(graphicsLab, graphicsLab),
    visualWorkbench: Object.assign(visualWorkbench, visualWorkbench),
    clusters: Object.assign(clusters, clusters),
    metricGroups: Object.assign(metricGroups, metricGroups),
    subClusters: Object.assign(subClusters, subClusters),
    funnels: Object.assign(funnels, funnels),
    scenarios: Object.assign(scenarios, scenarios),
    pages: Object.assign(pages, pages),
    ctas: Object.assign(ctas, ctas),
    leadBoxes: Object.assign(leadBoxes, leadBoxes),
    popups: Object.assign(popups, popups),
    conversions: Object.assign(conversions, conversions),
    attribution: Object.assign(attribution, attribution),
}

export default analytics
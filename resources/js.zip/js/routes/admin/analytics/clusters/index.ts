import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:64
* @route '/admin/analytics/clusters/{clusterKey}'
*/
export const show = (args: { clusterKey: string | number } | [clusterKey: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/analytics/clusters/{clusterKey}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:64
* @route '/admin/analytics/clusters/{clusterKey}'
*/
show.url = (args: { clusterKey: string | number } | [clusterKey: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { clusterKey: args }
    }

    if (Array.isArray(args)) {
        args = {
            clusterKey: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        clusterKey: args.clusterKey,
    }

    return show.definition.url
            .replace('{clusterKey}', parsedArgs.clusterKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:64
* @route '/admin/analytics/clusters/{clusterKey}'
*/
show.get = (args: { clusterKey: string | number } | [clusterKey: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:64
* @route '/admin/analytics/clusters/{clusterKey}'
*/
show.head = (args: { clusterKey: string | number } | [clusterKey: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:64
* @route '/admin/analytics/clusters/{clusterKey}'
*/
const showForm = (args: { clusterKey: string | number } | [clusterKey: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:64
* @route '/admin/analytics/clusters/{clusterKey}'
*/
showForm.get = (args: { clusterKey: string | number } | [clusterKey: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:64
* @route '/admin/analytics/clusters/{clusterKey}'
*/
showForm.head = (args: { clusterKey: string | number } | [clusterKey: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const clusters = {
    show: Object.assign(show, show),
}

export default clusters
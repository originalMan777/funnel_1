import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:74
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}'
*/
export const show = (args: { clusterKey: string | number, subClusterKey: string | number } | [clusterKey: string | number, subClusterKey: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/analytics/clusters/{clusterKey}/{subClusterKey}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:74
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}'
*/
show.url = (args: { clusterKey: string | number, subClusterKey: string | number } | [clusterKey: string | number, subClusterKey: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            clusterKey: args[0],
            subClusterKey: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        clusterKey: args.clusterKey,
        subClusterKey: args.subClusterKey,
    }

    return show.definition.url
            .replace('{clusterKey}', parsedArgs.clusterKey.toString())
            .replace('{subClusterKey}', parsedArgs.subClusterKey.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:74
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}'
*/
show.get = (args: { clusterKey: string | number, subClusterKey: string | number } | [clusterKey: string | number, subClusterKey: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:74
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}'
*/
show.head = (args: { clusterKey: string | number, subClusterKey: string | number } | [clusterKey: string | number, subClusterKey: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:74
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}'
*/
const showForm = (args: { clusterKey: string | number, subClusterKey: string | number } | [clusterKey: string | number, subClusterKey: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:74
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}'
*/
showForm.get = (args: { clusterKey: string | number, subClusterKey: string | number } | [clusterKey: string | number, subClusterKey: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::show
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:74
* @route '/admin/analytics/clusters/{clusterKey}/{subClusterKey}'
*/
showForm.head = (args: { clusterKey: string | number, subClusterKey: string | number } | [clusterKey: string | number, subClusterKey: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const subClusters = {
    show: Object.assign(show, show),
}

export default subClusters
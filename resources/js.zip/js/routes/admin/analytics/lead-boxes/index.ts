import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1056
* @route '/admin/analytics/lead-boxes'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/analytics/lead-boxes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1056
* @route '/admin/analytics/lead-boxes'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1056
* @route '/admin/analytics/lead-boxes'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1056
* @route '/admin/analytics/lead-boxes'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1056
* @route '/admin/analytics/lead-boxes'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1056
* @route '/admin/analytics/lead-boxes'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1056
* @route '/admin/analytics/lead-boxes'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const leadBoxes = {
    index: Object.assign(index, index),
}

export default leadBoxes
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\Analytics\InterpretationController::index
* @see app/Http/Controllers/Admin/Analytics/InterpretationController.php:36
* @route '/admin/analytics/scenarios'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/analytics/scenarios',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\Analytics\InterpretationController::index
* @see app/Http/Controllers/Admin/Analytics/InterpretationController.php:36
* @route '/admin/analytics/scenarios'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\Analytics\InterpretationController::index
* @see app/Http/Controllers/Admin/Analytics/InterpretationController.php:36
* @route '/admin/analytics/scenarios'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\InterpretationController::index
* @see app/Http/Controllers/Admin/Analytics/InterpretationController.php:36
* @route '/admin/analytics/scenarios'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\InterpretationController::index
* @see app/Http/Controllers/Admin/Analytics/InterpretationController.php:36
* @route '/admin/analytics/scenarios'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\InterpretationController::index
* @see app/Http/Controllers/Admin/Analytics/InterpretationController.php:36
* @route '/admin/analytics/scenarios'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\InterpretationController::index
* @see app/Http/Controllers/Admin/Analytics/InterpretationController.php:36
* @route '/admin/analytics/scenarios'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const scenarios = {
    index: Object.assign(index, index),
}

export default scenarios
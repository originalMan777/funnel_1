import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1080
* @route '/admin/analytics/conversions'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/analytics/conversions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1080
* @route '/admin/analytics/conversions'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1080
* @route '/admin/analytics/conversions'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1080
* @route '/admin/analytics/conversions'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1080
* @route '/admin/analytics/conversions'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1080
* @route '/admin/analytics/conversions'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\Analytics\ReportController::index
* @see app/Http/Controllers/Admin/Analytics/ReportController.php:1080
* @route '/admin/analytics/conversions'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

const conversions = {
    index: Object.assign(index, index),
}

export default conversions
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Public\LeadController::store
* @see app/Http/Controllers/Public/LeadController.php:104
* @route '/leads'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/leads',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Public\LeadController::store
* @see app/Http/Controllers/Public/LeadController.php:104
* @route '/leads'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\LeadController::store
* @see app/Http/Controllers/Public/LeadController.php:104
* @route '/leads'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Public\LeadController::store
* @see app/Http/Controllers/Public/LeadController.php:104
* @route '/leads'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Public\LeadController::store
* @see app/Http/Controllers/Public/LeadController.php:104
* @route '/leads'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const leads = {
    store: Object.assign(store, store),
}

export default leads
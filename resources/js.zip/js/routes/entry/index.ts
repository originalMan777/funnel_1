import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Public\MagnetEntryController::quiz
* @see app/Http/Controllers/Public/MagnetEntryController.php:18
* @route '/entry/quiz'
*/
export const quiz = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quiz.url(options),
    method: 'get',
})

quiz.definition = {
    methods: ["get","head"],
    url: '/entry/quiz',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\MagnetEntryController::quiz
* @see app/Http/Controllers/Public/MagnetEntryController.php:18
* @route '/entry/quiz'
*/
quiz.url = (options?: RouteQueryOptions) => {
    return quiz.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\MagnetEntryController::quiz
* @see app/Http/Controllers/Public/MagnetEntryController.php:18
* @route '/entry/quiz'
*/
quiz.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quiz.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\MagnetEntryController::quiz
* @see app/Http/Controllers/Public/MagnetEntryController.php:18
* @route '/entry/quiz'
*/
quiz.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quiz.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Public\MagnetEntryController::quiz
* @see app/Http/Controllers/Public/MagnetEntryController.php:18
* @route '/entry/quiz'
*/
const quizForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: quiz.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\MagnetEntryController::quiz
* @see app/Http/Controllers/Public/MagnetEntryController.php:18
* @route '/entry/quiz'
*/
quizForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: quiz.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\MagnetEntryController::quiz
* @see app/Http/Controllers/Public/MagnetEntryController.php:18
* @route '/entry/quiz'
*/
quizForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: quiz.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

quiz.form = quizForm

const entry = {
    quiz: Object.assign(quiz, quiz),
}

export default entry
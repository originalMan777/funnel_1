import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see routes/web.php:46
* @route '/sellers-strategy'
*/
export const strategy = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: strategy.url(options),
    method: 'get',
})

strategy.definition = {
    methods: ["get","head"],
    url: '/sellers-strategy',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:46
* @route '/sellers-strategy'
*/
strategy.url = (options?: RouteQueryOptions) => {
    return strategy.definition.url + queryParams(options)
}

/**
* @see routes/web.php:46
* @route '/sellers-strategy'
*/
strategy.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: strategy.url(options),
    method: 'get',
})

/**
* @see routes/web.php:46
* @route '/sellers-strategy'
*/
strategy.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: strategy.url(options),
    method: 'head',
})

/**
* @see routes/web.php:46
* @route '/sellers-strategy'
*/
const strategyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: strategy.url(options),
    method: 'get',
})

/**
* @see routes/web.php:46
* @route '/sellers-strategy'
*/
strategyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: strategy.url(options),
    method: 'get',
})

/**
* @see routes/web.php:46
* @route '/sellers-strategy'
*/
strategyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: strategy.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

strategy.form = strategyForm

const sellers = {
    strategy: Object.assign(strategy, strategy),
}

export default sellers
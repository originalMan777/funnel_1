import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see routes/web.php:42
* @route '/buyers-strategy'
*/
export const strategy = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: strategy.url(options),
    method: 'get',
})

strategy.definition = {
    methods: ["get","head"],
    url: '/buyers-strategy',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:42
* @route '/buyers-strategy'
*/
strategy.url = (options?: RouteQueryOptions) => {
    return strategy.definition.url + queryParams(options)
}

/**
* @see routes/web.php:42
* @route '/buyers-strategy'
*/
strategy.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: strategy.url(options),
    method: 'get',
})

/**
* @see routes/web.php:42
* @route '/buyers-strategy'
*/
strategy.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: strategy.url(options),
    method: 'head',
})

/**
* @see routes/web.php:42
* @route '/buyers-strategy'
*/
const strategyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: strategy.url(options),
    method: 'get',
})

/**
* @see routes/web.php:42
* @route '/buyers-strategy'
*/
strategyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: strategy.url(options),
    method: 'get',
})

/**
* @see routes/web.php:42
* @route '/buyers-strategy'
*/
strategyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: strategy.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

strategy.form = strategyForm

const buyers = {
    strategy: Object.assign(strategy, strategy),
}

export default buyers
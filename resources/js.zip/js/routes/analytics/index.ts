import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Analytics\IngestController::__invoke
* @see app/Http/Controllers/Analytics/IngestController.php:20
* @route '/analytics/ingest'
*/
export const ingest = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ingest.url(options),
    method: 'post',
})

ingest.definition = {
    methods: ["post"],
    url: '/analytics/ingest',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Analytics\IngestController::__invoke
* @see app/Http/Controllers/Analytics/IngestController.php:20
* @route '/analytics/ingest'
*/
ingest.url = (options?: RouteQueryOptions) => {
    return ingest.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Analytics\IngestController::__invoke
* @see app/Http/Controllers/Analytics/IngestController.php:20
* @route '/analytics/ingest'
*/
ingest.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ingest.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Analytics\IngestController::__invoke
* @see app/Http/Controllers/Analytics/IngestController.php:20
* @route '/analytics/ingest'
*/
const ingestForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: ingest.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Analytics\IngestController::__invoke
* @see app/Http/Controllers/Analytics/IngestController.php:20
* @route '/analytics/ingest'
*/
ingestForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: ingest.url(options),
    method: 'post',
})

ingest.form = ingestForm

const analytics = {
    ingest: Object.assign(ingest, ingest),
}

export default analytics
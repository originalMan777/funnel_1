import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import test from './test'
/**
* @see \App\Http\Controllers\Public\PostController::index
* @see app/Http/Controllers/Public/PostController.php:24
* @route '/blog'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/blog',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\PostController::index
* @see app/Http/Controllers/Public/PostController.php:24
* @route '/blog'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\PostController::index
* @see app/Http/Controllers/Public/PostController.php:24
* @route '/blog'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::index
* @see app/Http/Controllers/Public/PostController.php:24
* @route '/blog'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Public\PostController::index
* @see app/Http/Controllers/Public/PostController.php:24
* @route '/blog'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::index
* @see app/Http/Controllers/Public/PostController.php:24
* @route '/blog'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::index
* @see app/Http/Controllers/Public/PostController.php:24
* @route '/blog'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Public\PostController::category
* @see app/Http/Controllers/Public/PostController.php:266
* @route '/blog/category/{slug}'
*/
export const category = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: category.url(args, options),
    method: 'get',
})

category.definition = {
    methods: ["get","head"],
    url: '/blog/category/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\PostController::category
* @see app/Http/Controllers/Public/PostController.php:266
* @route '/blog/category/{slug}'
*/
category.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return category.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\PostController::category
* @see app/Http/Controllers/Public/PostController.php:266
* @route '/blog/category/{slug}'
*/
category.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: category.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::category
* @see app/Http/Controllers/Public/PostController.php:266
* @route '/blog/category/{slug}'
*/
category.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: category.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Public\PostController::category
* @see app/Http/Controllers/Public/PostController.php:266
* @route '/blog/category/{slug}'
*/
const categoryForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: category.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::category
* @see app/Http/Controllers/Public/PostController.php:266
* @route '/blog/category/{slug}'
*/
categoryForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: category.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::category
* @see app/Http/Controllers/Public/PostController.php:266
* @route '/blog/category/{slug}'
*/
categoryForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: category.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

category.form = categoryForm

/**
* @see \App\Http\Controllers\Public\PostController::tag
* @see app/Http/Controllers/Public/PostController.php:302
* @route '/blog/tag/{slug}'
*/
export const tag = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tag.url(args, options),
    method: 'get',
})

tag.definition = {
    methods: ["get","head"],
    url: '/blog/tag/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\PostController::tag
* @see app/Http/Controllers/Public/PostController.php:302
* @route '/blog/tag/{slug}'
*/
tag.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return tag.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\PostController::tag
* @see app/Http/Controllers/Public/PostController.php:302
* @route '/blog/tag/{slug}'
*/
tag.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tag.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::tag
* @see app/Http/Controllers/Public/PostController.php:302
* @route '/blog/tag/{slug}'
*/
tag.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tag.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Public\PostController::tag
* @see app/Http/Controllers/Public/PostController.php:302
* @route '/blog/tag/{slug}'
*/
const tagForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: tag.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::tag
* @see app/Http/Controllers/Public/PostController.php:302
* @route '/blog/tag/{slug}'
*/
tagForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: tag.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::tag
* @see app/Http/Controllers/Public/PostController.php:302
* @route '/blog/tag/{slug}'
*/
tagForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: tag.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

tag.form = tagForm

/**
* @see \App\Http\Controllers\Public\PostController::show
* @see app/Http/Controllers/Public/PostController.php:167
* @route '/blog/{slug}'
*/
export const show = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/blog/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\PostController::show
* @see app/Http/Controllers/Public/PostController.php:167
* @route '/blog/{slug}'
*/
show.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return show.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\PostController::show
* @see app/Http/Controllers/Public/PostController.php:167
* @route '/blog/{slug}'
*/
show.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::show
* @see app/Http/Controllers/Public/PostController.php:167
* @route '/blog/{slug}'
*/
show.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Public\PostController::show
* @see app/Http/Controllers/Public/PostController.php:167
* @route '/blog/{slug}'
*/
const showForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::show
* @see app/Http/Controllers/Public/PostController.php:167
* @route '/blog/{slug}'
*/
showForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Public\PostController::show
* @see app/Http/Controllers/Public/PostController.php:167
* @route '/blog/{slug}'
*/
showForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const blog = {
    test: Object.assign(test, test),
    index: Object.assign(index, index),
    category: Object.assign(category, category),
    tag: Object.assign(tag, tag),
    show: Object.assign(show, show),
}

export default blog
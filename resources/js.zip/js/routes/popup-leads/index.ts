import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Public\PopupLeadController::store
* @see app/Http/Controllers/Public/PopupLeadController.php:35
* @route '/popup-leads'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/popup-leads',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Public\PopupLeadController::store
* @see app/Http/Controllers/Public/PopupLeadController.php:35
* @route '/popup-leads'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\PopupLeadController::store
* @see app/Http/Controllers/Public/PopupLeadController.php:35
* @route '/popup-leads'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Public\PopupLeadController::store
* @see app/Http/Controllers/Public/PopupLeadController.php:35
* @route '/popup-leads'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Public\PopupLeadController::store
* @see app/Http/Controllers/Public/PopupLeadController.php:35
* @route '/popup-leads'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

const popupLeads = {
    store: Object.assign(store, store),
}

export default popupLeads
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\QO\QORuntimeController::start
* @see app/Http/Controllers/QO/QORuntimeController.php:16
* @route '/q/{slug}/start'
*/
export const start = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/q/{slug}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QO\QORuntimeController::start
* @see app/Http/Controllers/QO/QORuntimeController.php:16
* @route '/q/{slug}/start'
*/
start.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return start.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QO\QORuntimeController::start
* @see app/Http/Controllers/QO/QORuntimeController.php:16
* @route '/q/{slug}/start'
*/
start.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QO\QORuntimeController::start
* @see app/Http/Controllers/QO/QORuntimeController.php:16
* @route '/q/{slug}/start'
*/
const startForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QO\QORuntimeController::start
* @see app/Http/Controllers/QO/QORuntimeController.php:16
* @route '/q/{slug}/start'
*/
startForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: start.url(args, options),
    method: 'post',
})

start.form = startForm

/**
* @see \App\Http\Controllers\QO\QORuntimeController::answer
* @see app/Http/Controllers/QO/QORuntimeController.php:51
* @route '/q/{slug}/answer'
*/
export const answer = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: answer.url(args, options),
    method: 'post',
})

answer.definition = {
    methods: ["post"],
    url: '/q/{slug}/answer',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QO\QORuntimeController::answer
* @see app/Http/Controllers/QO/QORuntimeController.php:51
* @route '/q/{slug}/answer'
*/
answer.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return answer.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QO\QORuntimeController::answer
* @see app/Http/Controllers/QO/QORuntimeController.php:51
* @route '/q/{slug}/answer'
*/
answer.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: answer.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QO\QORuntimeController::answer
* @see app/Http/Controllers/QO/QORuntimeController.php:51
* @route '/q/{slug}/answer'
*/
const answerForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: answer.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QO\QORuntimeController::answer
* @see app/Http/Controllers/QO/QORuntimeController.php:51
* @route '/q/{slug}/answer'
*/
answerForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: answer.url(args, options),
    method: 'post',
})

answer.form = answerForm

/**
* @see \App\Http\Controllers\QO\QORuntimeController::capture
* @see app/Http/Controllers/QO/QORuntimeController.php:86
* @route '/q/{slug}/capture'
*/
export const capture = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: capture.url(args, options),
    method: 'post',
})

capture.definition = {
    methods: ["post"],
    url: '/q/{slug}/capture',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QO\QORuntimeController::capture
* @see app/Http/Controllers/QO/QORuntimeController.php:86
* @route '/q/{slug}/capture'
*/
capture.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return capture.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QO\QORuntimeController::capture
* @see app/Http/Controllers/QO/QORuntimeController.php:86
* @route '/q/{slug}/capture'
*/
capture.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: capture.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QO\QORuntimeController::capture
* @see app/Http/Controllers/QO/QORuntimeController.php:86
* @route '/q/{slug}/capture'
*/
const captureForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: capture.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QO\QORuntimeController::capture
* @see app/Http/Controllers/QO/QORuntimeController.php:86
* @route '/q/{slug}/capture'
*/
captureForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: capture.url(args, options),
    method: 'post',
})

capture.form = captureForm

/**
* @see \App\Http\Controllers\QO\QORuntimeController::complete
* @see app/Http/Controllers/QO/QORuntimeController.php:130
* @route '/q/{slug}/complete'
*/
export const complete = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/q/{slug}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\QO\QORuntimeController::complete
* @see app/Http/Controllers/QO/QORuntimeController.php:130
* @route '/q/{slug}/complete'
*/
complete.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return complete.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\QO\QORuntimeController::complete
* @see app/Http/Controllers/QO/QORuntimeController.php:130
* @route '/q/{slug}/complete'
*/
complete.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QO\QORuntimeController::complete
* @see app/Http/Controllers/QO/QORuntimeController.php:130
* @route '/q/{slug}/complete'
*/
const completeForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: complete.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\QO\QORuntimeController::complete
* @see app/Http/Controllers/QO/QORuntimeController.php:130
* @route '/q/{slug}/complete'
*/
completeForm.post = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: complete.url(args, options),
    method: 'post',
})

complete.form = completeForm

const runtime = {
    start: Object.assign(start, start),
    answer: Object.assign(answer, answer),
    capture: Object.assign(capture, capture),
    complete: Object.assign(complete, complete),
}

export default runtime